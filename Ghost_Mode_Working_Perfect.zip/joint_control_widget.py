from PyQt6.QtWidgets import QWidget, QHBoxLayout, QLabel, QSlider
from PyQt6.QtCore import Qt, pyqtSignal, QTimer
from styled_button import StyledButton


class JointControlWidget(QWidget):
    hover_enter = pyqtSignal(str, str)   # display_name, direction
    hover_leave = pyqtSignal(str)        # display_name
    joint_velocity = pyqtSignal(str, float)  # display_name, velocity
    joint_stop = pyqtSignal(str)         # display_name

    def __init__(self, display_name, joint_index, parent=None):
        super().__init__(parent)
        self.display_name = display_name  # 'J1', 'J2', etc.
        self.joint_index = joint_index
        self.actual_joint_name = None  # Will be set by parent
        self.velocity = 0.2  # rad/s default
        self.multiplier = 1.0

        layout = QHBoxLayout()
        self.name_label = QLabel(display_name)
        self.minus_btn = StyledButton("−")
        self.minus_btn.setProperty("direction", "minus")
        self.value_label = QLabel("0.00")
        self.plus_btn = StyledButton("+")
        self.plus_btn.setProperty("direction", "plus")

        self.minus_btn.pressed.connect(lambda: self.start_motion(-1))
        self.minus_btn.released.connect(self.stop_motion)
        self.plus_btn.pressed.connect(lambda: self.start_motion(1))
        self.plus_btn.released.connect(self.stop_motion)

        # Velocity slider
        self.slider = QSlider(Qt.Orientation.Horizontal)
        self.slider.setRange(1,100)
        self.slider.setValue(20)
        self.slider.valueChanged.connect(lambda v: setattr(self, 'multiplier', v/20.0))

        layout.addWidget(self.name_label)
        layout.addWidget(self.minus_btn)
        layout.addWidget(self.value_label)
        layout.addWidget(self.plus_btn)
        layout.addWidget(self.slider)
        self.setLayout(layout)

        self.minus_btn.installEventFilter(self)
        self.plus_btn.installEventFilter(self)

    def eventFilter(self, obj, event):
        if event.type() == event.Type.Enter:
            if obj == self.minus_btn:
                self.hover_enter.emit(self.display_name, "minus")
            elif obj == self.plus_btn:
                self.hover_enter.emit(self.display_name, "plus")
        elif event.type() == event.Type.Leave:
            self.hover_leave.emit(self.display_name)
        return super().eventFilter(obj, event)

    def start_motion(self, direction):
        vel = direction * self.velocity * self.multiplier
        self.joint_velocity.emit(self.display_name, vel)
        # Visual feedback
        if direction > 0:
            self.plus_btn.setStyleSheet("background-color: #4a7a4a; border-color: #6aaa6a;")
            self.minus_btn.setStyleSheet("")
        else:
            self.minus_btn.setStyleSheet("background-color: #7a4a4a; border-color: #aa6a6a;")
            self.plus_btn.setStyleSheet("")

    def stop_motion(self):
        self.joint_stop.emit(self.display_name)
        self.minus_btn.setStyleSheet("")
        self.plus_btn.setStyleSheet("")

    def update_value(self, value):
        self.value_label.setText(f"{value:.2f}")
        if abs(value) > 0.01:
            self.value_label.setStyleSheet("color: #ff6b6b; background-color: #1a1a2e; border: 1px solid #ff6b6b; border-radius: 4px; padding: 4px; font-size: 14px; font-weight: bold; min-width: 70px;")
        else:
            self.value_label.setStyleSheet("color: #ffffff; background-color: #1a1a2e; border: 1px solid #3a3a5e; border-radius: 4px; padding: 4px; font-size: 14px; font-weight: bold; min-width: 70px;")