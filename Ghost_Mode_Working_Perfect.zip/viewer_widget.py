"""
VTK 3D Robot Viewer for Nextup Cobot HMI
"""
import os
import math
import sys
from PyQt6.QtWidgets import QWidget, QVBoxLayout, QSizePolicy, QLabel, QFrame, QGridLayout
from PyQt6.QtCore import QTimer, pyqtSignal, Qt
import rclpy
from geometry_msgs.msg import TransformStamped

try:
    import vtk
    from vtk.qt.QVTKRenderWindowInteractor import QVTKRenderWindowInteractor
    VTK_AVAILABLE = True
except ImportError:
    VTK_AVAILABLE = False
    print("Error: VTK not installed")

try:
    import tf2_ros
    from tf2_ros import TransformException
    ROS2_AVAILABLE = True
except ImportError:
    ROS2_AVAILABLE = False

try:
    from moveit_msgs.msg import RobotState
except ImportError:
    RobotState = None

from urdf_parser import URDFParser


class Robot3DViewer(QWidget):
    """VTK-based 3D robot visualization widget"""
    
    joint_values_updated = pyqtSignal(list, list)
    
    def __init__(self, parent=None, urdf_path=None, mesh_path=None):
        super().__init__(parent)
        
        script_dir = os.path.dirname(os.path.abspath(__file__))
        
        # Find URDF
        if urdf_path is None:
            candidates = [
                os.path.join(script_dir, "nextupCobot.urdf.xacro"),
                os.path.join(script_dir, "nextupCobot.urdf"),
                os.path.expanduser("~/NextupRobot/src/nextup_moveit_config/urdf/nextupCobot.urdf.xacro"),
            ]
            for c in candidates:
                if os.path.exists(c):
                    urdf_path = c
                    break
        
        self.urdf_path = urdf_path
        self.mesh_path = mesh_path or os.path.join(script_dir, "meshes/")
        self.urdf_parser = URDFParser(self.urdf_path)
        print(self.urdf_parser.links.keys())
        # Real robot actors
        self.link_actors = {}
        self.link_transforms = {}
        self.link_colors = {}
        self.link_original_colors = {}
        self.link_names = []
        
        # Ghost robot actors
        self.ghost_actors = []
        self.ghost_link_actors = {}
        self.ghost_visible = False
        self.ghost_waypoints = []
        
        # NEW: Animation system for trajectory
        self.animation_timer = QTimer()
        self.animation_timer.timeout.connect(self._animate_ghost_frame)
        self.animation_frame = 0
        self.animation_speed = 50  # ms per frame
        
        # Joint arrows
        self.joint_arrows = {}
        self.joint_arrow_visible = {}
        
        # TF
        self.tf_buffer = None
        self.tf_listener = None
        self.tf_initialized = False
        
        # End-effector solid coordinate axis (TF-style triad), like RViz's
        # "Axes" display attached to a frame. One for the real (live) robot,
        # one for the ghost preview so you can see the frame Cartesian jogs
        # are actually applied in. Must match MoveItPlanner's ee_link.
        self.ee_link_name = 'link6'
        self.ee_axes_actor = None
        self.ghost_ee_axes_actor = None
        
        # Store latest pose for debug
        self.latest_ee_pose = None
        self.latest_joint_positions = {}
        
        # Setup VTK
        self.setup_vtk()
        self.load_robot_meshes()
        self.setup_camera()
        self.create_joint_arrows()
        self.create_ee_axes()
        
        # Timer for TF updates
        self.update_timer = QTimer()
        self.update_timer.setInterval(50)  # 20 Hz
        self.update_timer.timeout.connect(self.update_from_tf)
        self.update_timer.start()
        
        # ===== DEBUG OVERLAY =====
        self.setup_debug_overlay()
        
        print(f"✓ Robot3DViewer initialized")
        print(f"  URDF: {self.urdf_path}")
        print(f"  Mesh path: {self.mesh_path}")
        print(f"  Links: {list(self.link_actors.keys())}")
    
    def setup_debug_overlay(self):
        """Create a debug overlay showing current robot pose in the corner"""
        # Create a frame for the debug info
        self.debug_frame = QFrame(self)
        self.debug_frame.setStyleSheet("""
            QFrame {
                background-color: rgba(10, 10, 26, 230);
                border: 1px solid #2a2a4a;
                border-radius: 8px;
                padding: 10px;
            }
            QLabel {
                color: #c0c0e0;
                font-family: monospace;
                font-size: 11px;
                background-color: transparent;
            }
            .title-label {
                color: #6a6aae;
                font-weight: bold;
                font-size: 12px;
            }
            .value-label {
                color: #8a8ace;
                font-weight: bold;
            }
            .status-ok {
                color: #4aee6a;
            }
            .status-warning {
                color: #ffaa44;
            }
            .status-error {
                color: #ff4444;
            }
            .section-label {
                color: #6a6aae;
                font-size: 10px;
                font-weight: bold;
                border-bottom: 1px solid #2a2a4a;
                padding-bottom: 2px;
            }
        """)
        self.debug_frame.setFixedWidth(400)
        self.debug_frame.move(10, 10)  # Top-left corner
        
        # Use grid layout for better organization
        debug_layout = QGridLayout(self.debug_frame)
        debug_layout.setSpacing(3)
        debug_layout.setContentsMargins(10, 10, 10, 10)
        
        row = 0
        
        # Title
        title_label = QLabel("🔧 ROBOT STATE DEBUG")
        title_label.setProperty("class", "title-label")
        debug_layout.addWidget(title_label, row, 0, 1, 2)
        row += 1
        
        # Separator
        sep = QLabel("─" * 45)
        sep.setStyleSheet("color: #2a2a4a;")
        debug_layout.addWidget(sep, row, 0, 1, 2)
        row += 1
        
        # --- EE POSE Section ---
        pose_title = QLabel("📐 END-EFFECTOR POSE (link6)")
        pose_title.setProperty("class", "section-label")
        debug_layout.addWidget(pose_title, row, 0, 1, 2)
        row += 1
        
        # Position
        debug_layout.addWidget(QLabel("Position:"), row, 0)
        self.ee_pos_label = QLabel("--")
        self.ee_pos_label.setProperty("class", "value-label")
        debug_layout.addWidget(self.ee_pos_label, row, 1)
        row += 1
        
        # Orientation (Quaternion)
        debug_layout.addWidget(QLabel("Orient (xyzw):"), row, 0)
        self.ee_orient_label = QLabel("--")
        self.ee_orient_label.setProperty("class", "value-label")
        debug_layout.addWidget(self.ee_orient_label, row, 1)
        row += 1
        
        # Orientation (RPY)
        debug_layout.addWidget(QLabel("Orient (RPY):"), row, 0)
        self.ee_rpy_label = QLabel("--")
        self.ee_rpy_label.setProperty("class", "value-label")
        debug_layout.addWidget(self.ee_rpy_label, row, 1)
        row += 1
        
        # Separator
        sep2 = QLabel("─" * 45)
        sep2.setStyleSheet("color: #2a2a4a;")
        debug_layout.addWidget(sep2, row, 0, 1, 2)
        row += 1
        
        # --- JOINT POSITIONS Section ---
        joint_title = QLabel("⚙️ JOINT POSITIONS")
        joint_title.setProperty("class", "section-label")
        debug_layout.addWidget(joint_title, row, 0, 1, 2)
        row += 1
        
        # Joint labels in two columns for compactness
        self.joint_labels = {}
        joint_names = ['joint1', 'joint2', 'joint3', 'joint4', 'joint5', 'joint6']
        display_names = ['J1', 'J2', 'J3', 'J4', 'J5', 'J6']
        
        for i, (jname, dname) in enumerate(zip(joint_names, display_names)):
            col = i % 2
            grid_row = row + (i // 2)
            debug_layout.addWidget(QLabel(f"{dname}:"), grid_row, col * 2)
            label = QLabel("--")
            label.setProperty("class", "value-label")
            label.setFixedWidth(70)
            self.joint_labels[jname] = label
            debug_layout.addWidget(label, grid_row, col * 2 + 1)
        
        row += 3  # 3 rows for joints (2 columns)
        
        # Separator
        sep3 = QLabel("─" * 45)
        sep3.setStyleSheet("color: #2a2a4a;")
        debug_layout.addWidget(sep3, row, 0, 1, 2)
        row += 1
        
        # --- STATUS Section ---
        status_title = QLabel("📡 STATUS")
        status_title.setProperty("class", "section-label")
        debug_layout.addWidget(status_title, row, 0, 1, 2)
        row += 1
        
        debug_layout.addWidget(QLabel("TF Status:"), row, 0)
        self.tf_status_label = QLabel("Not initialized")
        self.tf_status_label.setProperty("class", "status-error")
        debug_layout.addWidget(self.tf_status_label, row, 1)
        row += 1
        
        debug_layout.addWidget(QLabel("Links visible:"), row, 0)
        self.links_visible_label = QLabel("--")
        self.links_visible_label.setProperty("class", "value-label")
        debug_layout.addWidget(self.links_visible_label, row, 1)
        row += 1
        
        # Make the debug frame stay on top
        self.debug_frame.raise_()
        self.debug_frame.show()
        
        # Timer to update debug info
        self.debug_timer = QTimer()
        self.debug_timer.setInterval(200)  # 5 Hz - faster updates
        self.debug_timer.timeout.connect(self.update_debug_info)
        self.debug_timer.start()
    
    def quaternion_to_rpy(self, qx, qy, qz, qw):
        """Convert quaternion to roll, pitch, yaw"""
        # Roll (x-axis rotation)
        sinr_cosp = 2.0 * (qw * qx + qy * qz)
        cosr_cosp = 1.0 - 2.0 * (qx * qx + qy * qy)
        roll = math.atan2(sinr_cosp, cosr_cosp)
        
        # Pitch (y-axis rotation)
        sinp = 2.0 * (qw * qy - qz * qx)
        if abs(sinp) >= 1:
            pitch = math.copysign(math.pi / 2, sinp)
        else:
            pitch = math.asin(sinp)
        
        # Yaw (z-axis rotation)
        siny_cosp = 2.0 * (qw * qz + qx * qy)
        cosy_cosp = 1.0 - 2.0 * (qy * qy + qz * qz)
        yaw = math.atan2(siny_cosp, cosy_cosp)
        
        return roll, pitch, yaw
    
    def update_debug_info(self):
        """Update the debug overlay with current robot state"""
        try:
            # Update EE pose if available
            if self.latest_ee_pose:
                pos = self.latest_ee_pose['position']
                orient = self.latest_ee_pose['orientation']
                
                # Position
                self.ee_pos_label.setText(f"({pos[0]:.6f}, {pos[1]:.6f}, {pos[2]:.6f})")
                self.ee_pos_label.setStyleSheet("color: #8a8ace; font-weight: bold;")
                
                # Orientation (quaternion)
                self.ee_orient_label.setText(f"({orient[0]:.6f}, {orient[1]:.6f}, {orient[2]:.6f}, {orient[3]:.6f})")
                self.ee_orient_label.setStyleSheet("color: #8a8ace; font-weight: bold;")
                
                # Orientation (RPY)
                roll, pitch, yaw = self.quaternion_to_rpy(orient[0], orient[1], orient[2], orient[3])
                self.ee_rpy_label.setText(f"({math.degrees(roll):.2f}°, {math.degrees(pitch):.2f}°, {math.degrees(yaw):.2f}°)")
                self.ee_rpy_label.setStyleSheet("color: #8a8ace; font-weight: bold;")
            else:
                self.ee_pos_label.setText("--")
                self.ee_orient_label.setText("--")
                self.ee_rpy_label.setText("--")
            
            # Update joint positions
            if self.latest_joint_positions:
                for joint_name, label in self.joint_labels.items():
                    if joint_name in self.latest_joint_positions:
                        val = self.latest_joint_positions[joint_name]
                        label.setText(f"{val:.4f} rad")
                        label.setStyleSheet("color: #8a8ace; font-weight: bold;")
                    else:
                        label.setText("--")
                        label.setStyleSheet("color: #666;")
            
            # Update TF status
            if self.tf_initialized:
                self.tf_status_label.setText("✓ Active")
                self.tf_status_label.setProperty("class", "status-ok")
                self.tf_status_label.setStyleSheet("color: #4aee6a;")
            else:
                self.tf_status_label.setText("⏳ Waiting...")
                self.tf_status_label.setProperty("class", "status-warning")
                self.tf_status_label.setStyleSheet("color: #ffaa44;")
            
            # Update links visibility
            visible_links = []
            for link_name, actor in self.link_actors.items():
                if actor.GetVisibility():
                    visible_links.append(link_name)
            self.links_visible_label.setText(f"{len(visible_links)}/{len(self.link_actors)} links")
            self.links_visible_label.setStyleSheet("color: #8a8ace; font-weight: bold;")
            
        except Exception as e:
            # Don't spam errors
            pass
    
    def setup_vtk(self):
        """Initialize VTK renderer and widget"""
        self.vtk_widget = QVTKRenderWindowInteractor(self)
        self.vtk_widget.setSizePolicy(QSizePolicy.Policy.Expanding, 
                                     QSizePolicy.Policy.Expanding)
        
        self.renderer = vtk.vtkRenderer()
        self.renderer.SetBackground(0.05, 0.05, 0.1)
        
        self.setup_lighting()
        self.vtk_widget.GetRenderWindow().AddRenderer(self.renderer)
        
        self.interactor = self.vtk_widget.GetRenderWindow().GetInteractor()
        self.interactor.SetInteractorStyle(vtk.vtkInteractorStyleTrackballCamera())
        
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(self.vtk_widget)
    
    def setup_lighting(self):
        """Setup lighting for the scene"""
        ambient = vtk.vtkLight()
        ambient.SetColor(0.4, 0.4, 0.4)
        ambient.SetIntensity(0.3)
        self.renderer.AddLight(ambient)
        
        light = vtk.vtkLight()
        light.SetPosition(2.5, -1.5, 2.0)
        light.SetFocalPoint(0, 0.2, 0.4)
        light.SetColor(1.0, 1.0, 1.0)
        light.SetIntensity(1.0)
        light.SetLightTypeToSceneLight()
        self.renderer.AddLight(light)
        
        fill = vtk.vtkLight()
        fill.SetPosition(-2.5, 1.5, 1.0)
        fill.SetFocalPoint(0, 0.2, 0.4)
        fill.SetColor(0.6, 0.6, 0.8)
        fill.SetIntensity(0.5)
        fill.SetLightTypeToSceneLight()
        self.renderer.AddLight(fill)
        
        back = vtk.vtkLight()
        back.SetPosition(0, 0.5, -2.0)
        back.SetFocalPoint(0, 0.2, 0.4)
        back.SetColor(0.4, 0.4, 0.6)
        back.SetIntensity(0.3)
        back.SetLightTypeToSceneLight()
        self.renderer.AddLight(back)
    
    def setup_camera(self):
        """Setup default camera position"""
        camera = self.renderer.GetActiveCamera()
        camera.SetFocalPoint(0.0, 0.0, 0.2)
        camera.SetPosition(0.0, -2.5, 0.8)
        camera.SetViewUp(0, 0, 1)
        self.renderer.ResetCameraClippingRange()
        self.add_floor_grid()
    
    def reset_camera(self):
        """Reset camera to default position"""
        camera = self.renderer.GetActiveCamera()
        camera.SetFocalPoint(0.0, 0.0, 0.2)
        camera.SetPosition(0.0, -2.5, 0.8)
        camera.SetViewUp(0, 0, 1)
        self.renderer.ResetCameraClippingRange()
        self.vtk_widget.GetRenderWindow().Render()
    
    def add_floor_grid(self):
        """Add a grid floor"""
        grid_source = vtk.vtkPlaneSource()
        grid_source.SetOrigin(-2.0, -2.0, 0.0)
        grid_source.SetPoint1(2.0, -2.0, 0.0)
        grid_source.SetPoint2(-2.0, 2.0, 0.0)
        grid_source.SetXResolution(20)
        grid_source.SetYResolution(20)
        
        grid_mapper = vtk.vtkPolyDataMapper()
        grid_mapper.SetInputConnection(grid_source.GetOutputPort())
        
        grid_actor = vtk.vtkActor()
        grid_actor.SetMapper(grid_mapper)
        grid_actor.GetProperty().SetColor(0.3, 0.3, 0.4)
        grid_actor.GetProperty().SetOpacity(0.5)
        grid_actor.GetProperty().SetRepresentationToWireframe()
        
        self.renderer.AddActor(grid_actor)
    
    def load_robot_meshes(self):
        """Load robot meshes from URDF or defaults"""
        print("Loading robot meshes...")
        
        # Get mesh filenames from URDF
        if self.urdf_parser.link_meshes:
            link_meshes = self.urdf_parser.link_meshes
        else:
            link_meshes = {
                'base_link': 'base_link.STL',
                'Link1': 'Link1.STL',
                'Link2': 'Link2.STL',
                'Link3': 'Link3.STL',
                'Link4': 'Link4.STL',
                'Link5': 'Link5.STL',
                'Link6': 'Link6.STL',
            }
        
        # Map to actual link names from URDF
        # The URDF might use different capitalization
        link_name_map = {}
        for link in self.urdf_parser.links.keys():
            link_lower = link.lower()
            for mesh_link in link_meshes.keys():
                if mesh_link.lower() == link_lower:
                    link_name_map[link] = mesh_link
                    break
        
        colors = {
            'base_link': (0.4, 0.4, 0.5),
            'Link1': (0.5, 0.6, 0.7),
            'Link2': (0.6, 0.7, 0.8),
            'Link3': (0.65, 0.75, 0.85),
            'Link4': (0.7, 0.8, 0.9),
            'Link5': (0.75, 0.82, 0.92),
            'Link6': (0.8, 0.85, 0.95),
        }
        
        # Load meshes for all links in URDF
        for link_name in self.urdf_parser.link_meshes.keys():
            if link_name in ["world", "ground_link", "end"]:
                continue
            # Find matching mesh file
            mesh_file = None
            for mesh_link, mesh_file_name in link_meshes.items():
                if mesh_link.lower() == link_name.lower():
                    mesh_file = mesh_file_name
                    break
            
            if mesh_file is None:
                # Try to find by name
                for mesh_link, mesh_file_name in link_meshes.items():
                    if link_name.lower() in mesh_link.lower() or mesh_link.lower() in link_name.lower():
                        mesh_file = mesh_file_name
                        break
            
            if mesh_file is None:
                print(f"  ⚠ No mesh found for {link_name}, using default")
                mesh_file = 'base_link.STL'
            
            color = colors.get(link_name, (0.7, 0.7, 0.8))
            if link_name not in colors:
                # Try case-insensitive match
                for key in colors:
                    if key.lower() == link_name.lower():
                        color = colors[key]
                        break
            
            self.link_colors[link_name] = color
            self.link_original_colors[link_name] = color
            print(f"{link_name} ---> {mesh_file}")
            actor = self._load_mesh(mesh_file, color)
            self.link_actors[link_name] = actor
            self.link_names.append(link_name)
            self.renderer.AddActor(actor)
            
            # Identity transform initially
            transform = vtk.vtkTransform()
            transform.Identity()
            self.link_transforms[link_name] = transform
            actor.SetUserTransform(transform)
            
            print(f"  Loaded {link_name} -> {mesh_file}")
        
        print(f"✓ Loaded {len(self.link_actors)} link meshes")
        
        # Create ghost actors by sharing mappers
        for link_name, actor in self.link_actors.items():
            ghost_actor = vtk.vtkActor()
            ghost_actor.SetMapper(actor.GetMapper())
            ghost_actor.GetProperty().SetColor(0.0, 0.8, 0.8) # Cyan ghost
            ghost_actor.GetProperty().SetOpacity(0.4)
            ghost_actor.GetProperty().SetSpecular(0.1)
            ghost_actor.SetVisibility(False)
            self.renderer.AddActor(ghost_actor)
            self.ghost_link_actors[link_name] = ghost_actor
    
    def _load_mesh(self, mesh_filename, color):
        """Load a mesh file"""
        try:
            # Try multiple paths with different cases
            mesh_paths = [
                os.path.join(self.mesh_path, mesh_filename),
                os.path.join(self.mesh_path, mesh_filename.lower()),
                os.path.join(self.mesh_path, mesh_filename.upper()),
                os.path.join(self.mesh_path, mesh_filename.capitalize()),
                mesh_filename,
            ]
            
            for path in mesh_paths:
                if os.path.exists(path):
                    print(f"    Found mesh: {path}")
                    if path.lower().endswith('.stl'):
                        reader = vtk.vtkSTLReader()
                        reader.SetFileName(path)
                        mapper = vtk.vtkPolyDataMapper()
                        mapper.SetInputConnection(reader.GetOutputPort())
                        actor = vtk.vtkActor()
                        actor.SetMapper(mapper)
                        actor.GetProperty().SetColor(color)
                        actor.GetProperty().SetSpecular(0.3)
                        actor.GetProperty().SetSpecularPower(20)
                        return actor
                    elif path.lower().endswith('.obj'):
                        reader = vtk.vtkOBJReader()
                        reader.SetFileName(path)
                        mapper = vtk.vtkPolyDataMapper()
                        mapper.SetInputConnection(reader.GetOutputPort())
                        actor = vtk.vtkActor()
                        actor.SetMapper(mapper)
                        actor.GetProperty().SetColor(color)
                        actor.GetProperty().SetSpecular(0.3)
                        actor.GetProperty().SetSpecularPower(20)
                        return actor
            
            # Fallback: create a box
            print(f"    ⚠ Mesh not found: {mesh_filename}, using placeholder")
            source = vtk.vtkCubeSource()
            source.SetXLength(0.05)
            source.SetYLength(0.05)
            source.SetZLength(0.05)
            mapper = vtk.vtkPolyDataMapper()
            mapper.SetInputConnection(source.GetOutputPort())
            actor = vtk.vtkActor()
            actor.SetMapper(mapper)
            actor.GetProperty().SetColor(color)
            return actor
            
        except Exception as e:
            print(f"    ⚠ Error loading mesh {mesh_filename}: {e}")
            source = vtk.vtkSphereSource()
            source.SetRadius(0.03)
            mapper = vtk.vtkPolyDataMapper()
            mapper.SetInputConnection(source.GetOutputPort())
            actor = vtk.vtkActor()
            actor.SetMapper(mapper)
            actor.GetProperty().SetColor(color)
            return actor
    
    def create_ee_axes(self):
        """
        Build the solid end-effector coordinate triads (X=red, Y=green,
        Z=blue), same convention RViz uses for its "Axes" display. One
        solid/opaque triad follows the real robot's live TF pose; one
        semi-transparent triad follows the ghost preview so it's visually
        distinguishable but still readable while a plan is being hovered.
        """
        self.ee_axes_actor = self._make_axes_actor(length=0.15, opacity=1.0)
        self.ee_axes_actor.SetVisibility(False)  # hidden until first TF lookup succeeds
        self.renderer.AddActor(self.ee_axes_actor)
        
        self.ghost_ee_axes_actor = self._make_axes_actor(length=0.15, opacity=0.55)
        self.ghost_ee_axes_actor.SetVisibility(False)  # hidden until a ghost trajectory is shown
        self.renderer.AddActor(self.ghost_ee_axes_actor)
    
    def _make_axes_actor(self, length=0.15, opacity=1.0):
        """Build one solid XYZ coordinate triad (vtkAxesActor)."""
        axes = vtk.vtkAxesActor()
        axes.SetTotalLength(length, length, length)
        axes.SetShaftType(vtk.vtkAxesActor.CYLINDER_SHAFT)
        axes.SetCylinderRadius(0.06)
        axes.SetConeRadius(0.35)
        axes.AxisLabelsOff()
        
        for caption in (axes.GetXAxisCaptionActor2D(), axes.GetYAxisCaptionActor2D(), axes.GetZAxisCaptionActor2D()):
            caption.GetCaptionTextProperty().SetFontSize(14)
            caption.GetCaptionTextProperty().ShadowOff()
            caption.GetCaptionTextProperty().BoldOff()
        
        if opacity < 1.0:
            for shaft_prop, tip_prop in (
                (axes.GetXAxisShaftProperty(), axes.GetXAxisTipProperty()),
                (axes.GetYAxisShaftProperty(), axes.GetYAxisTipProperty()),
                (axes.GetZAxisShaftProperty(), axes.GetZAxisTipProperty()),
            ):
                shaft_prop.SetOpacity(opacity)
                tip_prop.SetOpacity(opacity)
        
        return axes
    
    def create_joint_arrows(self):
        """Create arrows for joint visualization"""
        # Joint 1: Circular arrows
        joint1_pos = self.urdf_parser.get_joint_origin('joint1')
        base_x, base_y, base_z = joint1_pos[0] if joint1_pos else 0, joint1_pos[1] if len(joint1_pos) > 1 else 0, 0.0
        
        # CCW arrow (green, for +)
        self.joint1_ccw = self._create_circular_arrow(False, base_x, base_y - 0.5, base_z)
        self.joint1_ccw.GetProperty().SetColor(0.0, 0.8, 0.0)
        self.joint1_ccw.SetVisibility(False)
        self.renderer.AddActor(self.joint1_ccw)
        
        # CW arrow (red, for -)
        self.joint1_cw = self._create_circular_arrow(True, base_x, base_y + 0.5, base_z)
        self.joint1_cw.GetProperty().SetColor(0.8, 0.0, 0.0)
        self.joint1_cw.SetVisibility(False)
        self.renderer.AddActor(self.joint1_cw)
        
        self.joint_arrows['joint1'] = {'plus': self.joint1_ccw, 'minus': self.joint1_cw}
        
        # Joints 2, 3, 4: Straight arrows
        for joint_name in ['joint2', 'joint3', 'joint4']:
            self._create_static_arrow(joint_name)
    
    def _create_circular_arrow(self, clockwise, cx, cy, cz):
        """Create a circular arrow"""
        points = vtk.vtkPoints()
        lines = vtk.vtkCellArray()
        
        num_segments = 30
        radius = 0.3
        
        if clockwise:
            start = 0
            end = -2 * math.pi * 0.75
            step = (end - start) / num_segments
        else:
            start = 0
            end = 2 * math.pi * 0.75
            step = (end - start) / num_segments
        
        point_ids = []
        angle = start
        for i in range(num_segments + 1):
            x = cx + radius * math.cos(angle)
            y = cy + radius * math.sin(angle)
            pid = points.InsertNextPoint(x, y, cz)
            point_ids.append(pid)
            angle += step
        
        polyline = vtk.vtkPolyLine()
        polyline.GetPointIds().SetNumberOfIds(len(point_ids))
        for i, pid in enumerate(point_ids):
            polyline.GetPointIds().SetId(i, pid)
        lines.InsertNextCell(polyline)
        
        arc = vtk.vtkPolyData()
        arc.SetPoints(points)
        arc.SetLines(lines)
        
        # Arrow head
        if len(point_ids) >= 2:
            p1 = points.GetPoint(point_ids[-2])
            p2 = points.GetPoint(point_ids[-1])
            dx = p2[0] - p1[0]
            dy = p2[1] - p1[1]
            length = math.sqrt(dx*dx + dy*dy)
            if length > 0.001:
                dx /= length
                dy /= length
                
                head_len = 0.06
                head_wid = 0.03
                
                head_pts = vtk.vtkPoints()
                head_pts.InsertNextPoint(p2[0], p2[1], cz)
                head_pts.InsertNextPoint(
                    p2[0] - dx*head_len + dy*head_wid,
                    p2[1] - dy*head_len - dx*head_wid,
                    cz
                )
                head_pts.InsertNextPoint(
                    p2[0] - dx*head_len - dy*head_wid,
                    p2[1] - dy*head_len + dx*head_wid,
                    cz
                )
                
                head_cells = vtk.vtkCellArray()
                head_cells.InsertNextCell(3)
                head_cells.InsertCellPoint(0)
                head_cells.InsertCellPoint(1)
                head_cells.InsertCellPoint(2)
                
                head_poly = vtk.vtkPolyData()
                head_poly.SetPoints(head_pts)
                head_poly.SetPolys(head_cells)
                
                append = vtk.vtkAppendPolyData()
                append.AddInputData(arc)
                append.AddInputData(head_poly)
                append.Update()
                combined = append.GetOutput()
            else:
                combined = arc
        else:
            combined = arc
        
        mapper = vtk.vtkPolyDataMapper()
        mapper.SetInputData(combined)
        
        actor = vtk.vtkActor()
        actor.SetMapper(mapper)
        actor.GetProperty().SetLineWidth(2.0)
        actor.GetProperty().SetOpacity(0.0)
        
        return actor
    
    def _create_static_arrow(self, joint_name):
        """Create a straight arrow for a joint"""
        child_link = self.urdf_parser.get_link_for_joint(joint_name)
        if not child_link:
            return
        
        arrow = vtk.vtkArrowSource()
        arrow.SetTipLength(0.08)
        arrow.SetTipRadius(0.025)
        arrow.SetShaftRadius(0.01)
        
        # Plus arrow (green)
        plus = vtk.vtkActor()
        plus.SetMapper(vtk.vtkPolyDataMapper())
        plus.GetMapper().SetInputConnection(arrow.GetOutputPort())
        plus.GetProperty().SetColor(0.0, 0.8, 0.0)
        plus.SetVisibility(False)
        
        # Minus arrow (red)
        minus = vtk.vtkActor()
        minus.SetMapper(vtk.vtkPolyDataMapper())
        minus.GetMapper().SetInputConnection(arrow.GetOutputPort())
        minus.GetProperty().SetColor(0.8, 0.0, 0.0)
        minus.SetVisibility(False)
        
        self.joint_arrows[joint_name] = {
            'plus': plus,
            'minus': minus,
            'link': child_link,
            'axis': self.urdf_parser.get_joint_axis(joint_name)
        }
        
        self.renderer.AddActor(plus)
        self.renderer.AddActor(minus)
    
    def show_joint_arrow(self, joint_name, direction):
        """Show arrow for a joint"""
        self.hide_all_arrows()
        
        if joint_name not in self.joint_arrows:
            return
        
        arrow_info = self.joint_arrows[joint_name]
        
        if joint_name == 'joint1':
            actor = arrow_info.get(direction)
            if actor:
                actor.SetVisibility(True)
                actor.GetProperty().SetOpacity(1.0)
                self.vtk_widget.GetRenderWindow().Render()
            return
        
        # For joints 2-4, snap to mesh position
        actor = arrow_info.get(direction)
        child_link = arrow_info.get('link')
        
        if not actor or not child_link or child_link not in self.link_actors:
            return
        
        mesh_actor = self.link_actors[child_link]
        current_transform = mesh_actor.GetUserTransform()
        if not current_transform:
            return
        
        # Create transform for arrow
        arrow_transform = vtk.vtkTransform()
        arrow_transform.DeepCopy(current_transform)
        
        # Scale down
        arrow_transform.Scale(0.15, 0.15, 0.15)
        
        actor.SetUserTransform(arrow_transform)
        actor.SetVisibility(True)
        actor.GetProperty().SetOpacity(1.0)
        
        self.vtk_widget.GetRenderWindow().Render()
    
    def hide_all_arrows(self):
        """Hide all joint arrows"""
        for joint_name, arrow_info in self.joint_arrows.items():
            if joint_name == 'joint1':
                for d in ['plus', 'minus']:
                    actor = arrow_info.get(d)
                    if actor:
                        actor.SetVisibility(False)
            else:
                for d in ['plus', 'minus']:
                    actor = arrow_info.get(d)
                    if actor:
                        actor.SetVisibility(False)
        
        if self.vtk_widget:
            self.vtk_widget.GetRenderWindow().Render()
    
    def setup_tf(self, node):
        """Setup TF listener"""
        if ROS2_AVAILABLE and node is not None:
            try:
                self.tf_buffer = tf2_ros.Buffer()
                self.tf_listener = tf2_ros.TransformListener(self.tf_buffer, node)
                self.tf_initialized = True
                print("✓ TF2 buffer and listener created")
                print(f"  Waiting for transforms... (links: {list(self.link_actors.keys())})")
                return True
            except Exception as e:
                print(f"⚠ TF2 initialization failed: {e}")
                return False
        return False
    
    def update_from_tf(self):
        """Update robot poses from TF"""
        if not self.tf_initialized or self.tf_buffer is None:
            return
        
        try:
            any_update = False
            live_transforms = self._lookup_live_link_transforms(self.link_actors.keys())
            
            # Store joint positions from TF for debug
            joint_positions = {}
            for link_name in self.link_names:
                # Try to get joint angle from TF by looking at the transform
                # This is a simplified approach - in practice, you'd get joint states from /joint_states
                pass
            
            for link_name, vtk_transform in live_transforms.items():
                actor = self.link_actors[link_name]
                actor.SetUserTransform(vtk_transform)
                self.link_transforms[link_name] = vtk_transform
                any_update = True
            
            # Live end-effector axes triad — raw TF frame, no mesh visual
            # offset, so it represents the actual link frame Cartesian
            # jogs are computed relative to.
            if self.ee_axes_actor is not None:
                ee_transform = self._lookup_live_link_transforms(
                    [self.ee_link_name], apply_visual_offset=False
                ).get(self.ee_link_name)
                if ee_transform is not None:
                    self.ee_axes_actor.SetUserTransform(ee_transform)
                    self.ee_axes_actor.SetVisibility(True)
                    
                    # Store EE pose for debug
                    pos = ee_transform.GetPosition()
                    orient = ee_transform.GetOrientationWXYZ()
                    # Convert VTK orientation (angle, x, y, z) to quaternion
                    angle = math.radians(orient[0])
                    qx = orient[1] * math.sin(angle/2)
                    qy = orient[2] * math.sin(angle/2)
                    qz = orient[3] * math.sin(angle/2)
                    qw = math.cos(angle/2)
                    self.latest_ee_pose = {
                        'position': (pos[0], pos[1], pos[2]),
                        'orientation': (qx, qy, qz, qw)
                    }
                    any_update = True
            
            # Render if we had any update
            if any_update and self.vtk_widget:
                self.vtk_widget.GetRenderWindow().Render()
                
        except Exception as e:
            # Silently ignore errors
            pass

    def _lookup_live_link_transforms(self, link_names, apply_visual_offset=True):
        """
        Look up the CURRENT pose of each named link directly from TF,
        exactly the way RViz's RobotModel display does it: ask TF where
        the link is right now, rather than recomputing it via FK from a
        cached joint state that might be stale. This is the single
        source of truth for "where the real robot actually is" and is
        reused for the ghost's starting pose so the two can't disagree.

        Returns a dict of {link_name: vtk_transform} for whichever links
        currently have a valid transform available; links with no
        transform yet (e.g. still waiting on the first /joint_states
        message) are simply omitted, so callers should fall back to
        FK-from-joint-angles for anything missing.

        apply_visual_offset: when True (default), bakes in the mesh's
        <visual> origin offset from the URDF, matching what's needed to
        place a mesh actor correctly. When False, returns the raw TF
        frame with no offset — use this for coordinate-axis overlays,
        which should represent the actual link frame, not a mesh's
        cosmetic alignment offset.
        """
        transforms = {}
        if not self.tf_initialized or self.tf_buffer is None:
            return transforms
        
        for link_name in link_names:
            try:
                transform = self.tf_buffer.lookup_transform(
                    'base_link', link_name, rclpy.time.Time(), timeout=rclpy.duration.Duration(seconds=0.01)
                )
                if not transform:
                    continue
                
                vtk_transform = self._convert_tf_to_vtk(transform)
                
                if apply_visual_offset:
                    xyz, rpy = self.urdf_parser.get_visual_origin(link_name)
                    if xyz != [0,0,0] or rpy != [0,0,0]:
                        offset = vtk.vtkTransform()
                        offset.Translate(xyz[0], xyz[1], xyz[2])
                        # URDF rpy is a fixed-axis (extrinsic) X-then-Y-then-Z
                        # rotation: R = Rz * Ry * Rx, i.e. roll is applied to
                        # the point FIRST. vtkTransform is PreMultiply by
                        # default, so whichever Rotate*() call is made LAST
                        # is the one applied first to the point -- so we must
                        # call RotateZ, then RotateY, then RotateX (reverse
                        # of the naive X,Y,Z order) to get that composition.
                        offset.RotateZ(math.degrees(rpy[2]))
                        offset.RotateY(math.degrees(rpy[1]))
                        offset.RotateX(math.degrees(rpy[0]))
                        
                        combined = vtk.vtkTransform()
                        combined.Concatenate(vtk_transform)
                        combined.Concatenate(offset)
                        vtk_transform = combined
                
                transforms[link_name] = vtk_transform
                
            except (tf2_ros.LookupException, tf2_ros.ExtrapolationException):
                # Transform not available yet - this is normal
                pass
            except Exception:
                pass
        
        return transforms
    
    def _convert_tf_to_vtk(self, transform_stamped):
        """Convert ROS TransformStamped to vtkTransform"""
        vtk_transform = vtk.vtkTransform()
        vtk_transform.Identity()
        
        # Translation
        trans = transform_stamped.transform.translation
        vtk_transform.Translate(trans.x, trans.y, trans.z)
        
        # Rotation (quaternion to matrix)
        q = transform_stamped.transform.rotation
        qx, qy, qz, qw = q.x, q.y, q.z, q.w
        
        # Normalize
        norm = math.sqrt(qx*qx + qy*qy + qz*qz + qw*qw)
        if norm > 1e-6:
            qx, qy, qz, qw = qx/norm, qy/norm, qz/norm, qw/norm
        
        # Build rotation matrix
        matrix = vtk.vtkMatrix4x4()
        matrix.Identity()
        
        xx, yy, zz = qx*qx, qy*qy, qz*qz
        xy, xz, yz = qx*qy, qx*qz, qy*qz
        wx, wy, wz = qw*qx, qw*qy, qw*qz
        
        matrix.SetElement(0, 0, 1 - 2*(yy + zz))
        matrix.SetElement(0, 1, 2*(xy - wz))
        matrix.SetElement(0, 2, 2*(xz + wy))
        
        matrix.SetElement(1, 0, 2*(xy + wz))
        matrix.SetElement(1, 1, 1 - 2*(xx + zz))
        matrix.SetElement(1, 2, 2*(yz - wx))
        
        matrix.SetElement(2, 0, 2*(xz - wy))
        matrix.SetElement(2, 1, 2*(yz + wx))
        matrix.SetElement(2, 2, 1 - 2*(xx + yy))
        
        vtk_transform.Concatenate(matrix)
        return vtk_transform
    
    def get_transform_to_link(self, link_name, joint_positions):
        # Traverse up to find the path from base_link to link_name
        path = []
        curr = link_name
        while curr in self.urdf_parser.kinematic_chain and curr != 'base_link':
            parent = self.urdf_parser.kinematic_chain[curr]
            joint_name = self.urdf_parser.link_to_joint.get(curr)
            path.append((parent, joint_name, curr))
            curr = parent
        
        path.reverse()
        
        t = vtk.vtkTransform()
        t.Identity()
        
        for parent, joint_name, child in path:
            joint_data = self.urdf_parser.joint_transforms.get(joint_name)
            if not joint_data:
                continue
                
            pos = joint_data['position']  # (x, y, z)
            rot = joint_data.get('rotation', (0.0, 0.0, 0.0))  # (roll, pitch, yaw)
            
            # Parent-to-joint translation & rotation (Roll, Pitch, Yaw).
            # URDF rpy = fixed-axis extrinsic X,Y,Z => R = Rz*Ry*Rx (roll
            # applied to the point first). vtkTransform is PreMultiply, so
            # the LAST Rotate*() call is applied first to the point -- call
            # Z, Y, X (not X, Y, Z) to get the correct composition. This was
            # previously computing Rx*Ry*Rz, which is only equivalent when
            # rpy has a single non-zero axis -- for joints like joint2/joint6
            # here, all three axes are non-zero simultaneously, so the old
            # order produced a genuinely different (wrong) orientation that
            # compounds down the rest of the chain.
            t.Translate(pos[0], pos[1], pos[2])
            t.RotateZ(math.degrees(rot[2]))
            t.RotateY(math.degrees(rot[1]))
            t.RotateX(math.degrees(rot[0]))
            
            # Joint motion (rotation around joint axis)
            joint_type = joint_data.get('type', 'revolute')
            if joint_type in ['revolute', 'continuous']:
                angle = joint_positions.get(joint_name, 0.0)
                axis = self.urdf_parser.joint_axes.get(joint_name, [0.0, 0.0, 1.0])
                t.RotateWXYZ(math.degrees(angle), axis[0], axis[1], axis[2])
        
        # Apply visual offset for the target link (the mesh's <visual> origin)
        xyz, rpy = self.urdf_parser.get_visual_origin(link_name)
        if xyz != [0,0,0] or rpy != [0,0,0]:
            offset = vtk.vtkTransform()
            offset.Translate(xyz[0], xyz[1], xyz[2])
            offset.RotateZ(math.degrees(rpy[2]))
            offset.RotateY(math.degrees(rpy[1]))
            offset.RotateX(math.degrees(rpy[0]))
            
            combined = vtk.vtkTransform()
            combined.Concatenate(t)      # current transform from chain
            combined.Concatenate(offset) # visual offset applied ONCE
            t = combined
        
        return t

    def _validate_joint_names(self, joint_names):
        """
        Sanity-check that the joint names coming from a trajectory actually
        match the joint names parsed out of the URDF. get_transform_to_link()
        looks angles up with joint_positions.get(joint_name, 0.0) -- if the
        names don't match (different prefix, case, namespace, etc.) every
        lookup silently falls back to 0.0 and the FK chain collapses to the
        robot's zero/home pose, which then renders far away from wherever
        the real (TF-driven) arm actually is. Warn loudly instead of
        failing silently.
        """
        known = set(self.urdf_parser.joint_transforms.keys())
        given = set(joint_names)
        missing = given - known
        if missing:
            print("=" * 60)
            print("⚠⚠⚠ GHOST FK JOINT NAME MISMATCH ⚠⚠⚠")
            print(f"  Trajectory joint names: {sorted(given)}")
            print(f"  URDF joint names:       {sorted(known)}")
            print(f"  Not found in URDF:      {sorted(missing)}")
            print("  These joints will silently FK as angle=0.0, which will")
            print("  make the ghost/trajectory render at the wrong pose.")
            print("=" * 60)
            return False
        return True

    def show_ghost_trajectory(self, display_trajectory):
        """Display ghost robot for a planned trajectory"""
        self.clear_ghost()
        
        # Extract waypoints from trajectory...
        if not display_trajectory or not display_trajectory.trajectory:
            print("⚠ No trajectory data for ghost")
            return
        
        model_states = []
        if display_trajectory.trajectory and display_trajectory.trajectory[0].joint_trajectory.points:
            traj = display_trajectory.trajectory[0]
            joint_names = traj.joint_trajectory.joint_names
            self._validate_joint_names(joint_names)
            
            # --- THE FIX: Use the POINTS from the trajectory, NOT the raw IK solutions ---
            for pt in traj.joint_trajectory.points:
                state = RobotState()
                state.joint_state.name = joint_names
                state.joint_state.position = pt.positions  # This is ALREADY in the correct order!
                state.joint_state.velocity = pt.velocities if pt.velocities else [0.0] * len(joint_names)
                model_states.append(state)
        
        if not model_states:
            print("⚠ No waypoints in trajectory")
            return

        print(f"✓ Showing ghost with {len(model_states)} waypoints")
        
        self.ghost_waypoints = model_states
        self.ghost_visible = True
        self.animation_frame = 0
        
        # Get the first state
        start_state = model_states[0]
        joint_positions = dict(zip(start_state.joint_state.name, start_state.joint_state.position))
        
        # Drive the ghost purely from the planned waypoint's FK. Live TF is
        # NOT used here anymore: it reflects where the real robot is *right
        # now*, not the planned pose, and preferring it (as before) meant
        # the ghost body silently snapped to your current pose instead of
        # showing the plan whenever TF happened to be available (i.e.
        # basically always, on a running robot).
        for link_name, actor in self.ghost_link_actors.items():
            vtk_transform = self.get_transform_to_link(link_name, joint_positions)
            actor.SetUserTransform(vtk_transform)
            actor.SetVisibility(True)
        
        # Resolve the actual EE link key once (case-insensitive fallback,
        # same as before) and reuse it for both the axes triad and the
        # trajectory-path spheres below.
        ee_link = self.ee_link_name
        if ee_link not in self.ghost_link_actors:
            for k in self.ghost_link_actors.keys():
                if k.lower() == self.ee_link_name.lower():
                    ee_link = k
                    break
        
        # Ghost end-effector axes triad, posed at the start waypoint via FK
        # from the plan -- same source of truth as the body links above, so
        # the triad and the mesh can never disagree with each other.
        if self.ghost_ee_axes_actor is not None:
            ee_start_transform = self.get_transform_to_link(ee_link, joint_positions)
            self.ghost_ee_axes_actor.SetUserTransform(ee_start_transform)
            self.ghost_ee_axes_actor.SetVisibility(True)
            
        # 2. Draw the end-effector trajectory path as small spheres
        
        for i, state in enumerate(model_states):
            state_joints = dict(zip(state.joint_state.name, state.joint_state.position))
            ee_tf = self.get_transform_to_link(ee_link, state_joints)
            pos = ee_tf.GetPosition()
            
            # Create a small sphere at the end-effector position
            sphere = vtk.vtkSphereSource()
            sphere.SetRadius(0.01)
            mapper = vtk.vtkPolyDataMapper()
            mapper.SetInputConnection(sphere.GetOutputPort())
            
            actor = vtk.vtkActor()
            actor.SetMapper(mapper)
            
            # Color based on position in trajectory (gradient: cyan/green to blue)
            t = i / max(1, len(model_states) - 1)
            color = (0.0, 1.0 - 0.5 * t, 0.5 + 0.5 * t)  # Cyan to Blue gradient
            actor.GetProperty().SetColor(color)
            actor.GetProperty().SetOpacity(0.8)
            actor.SetPosition(pos)
            
            self.renderer.AddActor(actor)
            self.ghost_actors.append(actor)
        
        # START ANIMATION
        self._start_animation()
        self.vtk_widget.GetRenderWindow().Render()
    
    def clear_ghost(self):
        """Remove ghost robot"""
        self._stop_animation()
        for actor in self.ghost_link_actors.values():
            actor.SetVisibility(False)
        
        if self.ghost_ee_axes_actor is not None:
            self.ghost_ee_axes_actor.SetVisibility(False)
            
        for actor in self.ghost_actors:
            self.renderer.RemoveActor(actor)
        self.ghost_actors.clear()
        self.ghost_waypoints.clear()
        self.ghost_visible = False
        self.animation_frame = 0
        
        if self.vtk_widget:
            self.vtk_widget.GetRenderWindow().Render()
    
    # ========== ANIMATION METHODS ==========
    
    def _start_animation(self):
        """Start the trajectory animation loop"""
        self.animation_frame = 0
        self.animation_timer.start(self.animation_speed)
        print(f"▶ Animation started (speed: {self.animation_speed}ms/frame)")
    
    def _stop_animation(self):
        """Stop the trajectory animation"""
        self.animation_timer.stop()
        print("⏹ Animation stopped")
    
    def _animate_ghost_frame(self):
        """Move ghost robot to next waypoint"""
        if not self.ghost_waypoints or not self.ghost_visible:
            return
        
        # Get current waypoint (loop)
        num_waypoints = len(self.ghost_waypoints)
        if num_waypoints == 0:
            return
        
        # Loop animation
        self.animation_frame = self.animation_frame % num_waypoints
        current_state = self.ghost_waypoints[self.animation_frame]
        joint_positions = dict(zip(current_state.joint_state.name, current_state.joint_state.position))
        
        # Drive every frame from the waypoint's FK. Previously this checked
        # live TF first and used it whenever available -- which, on a
        # running robot, is essentially always -- so the ghost body just
        # sat at your CURRENT pose on every frame instead of animating
        # through the plan, while the (FK-only) trajectory dots showed the
        # real path. That mismatch is what made the plan look disconnected
        # from the arm. FK is now the single source of truth for the ghost,
        # matching the dots exactly.
        for link_name, actor in self.ghost_link_actors.items():
            vtk_transform = self.get_transform_to_link(link_name, joint_positions)
            actor.SetUserTransform(vtk_transform)
            actor.SetVisibility(True)
        
        # Move the ghost's end-effector axes triad along with the animation.
        if self.ghost_ee_axes_actor is not None:
            ee_link = self.ee_link_name
            if ee_link not in self.ghost_link_actors:
                for k in self.ghost_link_actors.keys():
                    if k.lower() == self.ee_link_name.lower():
                        ee_link = k
                        break
            
            ee_transform = self.get_transform_to_link(ee_link, joint_positions)
            self.ghost_ee_axes_actor.SetUserTransform(ee_transform)
            self.ghost_ee_axes_actor.SetVisibility(True)
        
        # Increment frame
        self.animation_frame += 1
        
        # Render
        self.vtk_widget.GetRenderWindow().Render()
    
    def set_animation_speed(self, ms_per_frame):
        """Set animation speed in milliseconds per frame"""
        self.animation_speed = max(10, min(500, ms_per_frame))
        if self.animation_timer.isActive():
            self.animation_timer.stop()
            self.animation_timer.start(self.animation_speed)
        print(f"Animation speed set to {self.animation_speed}ms/frame")
    
    def get_animation_speed(self):
        """Get animation speed"""
        return self.animation_speed