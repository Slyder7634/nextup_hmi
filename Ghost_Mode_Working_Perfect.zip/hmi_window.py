"""
Main HMI Window for Nextup Cobot HMI
"""
from PyQt6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QTabWidget, QSplitter, QLabel, QPushButton, QSlider,
    QStatusBar, QMessageBox, QGroupBox
)
from PyQt6.QtCore import Qt, QTimer, pyqtSignal
from joint_control_widget import JointControlWidget
from cartesian_control_widget import CartesianControlWidget
from viewer_widget import Robot3DViewer
from servo_controller import ServoController

# Try to import MoveIt planner
try:
    from moveit_planner import MoveItPlanner
    MOVEIT_AVAILABLE = True
except ImportError:
    MOVEIT_AVAILABLE = False
    print("⚠ MoveIt planner not available")

from ros_worker import RosWorker


class RobotHMI(QMainWindow):
    """Main HMI Application Window"""
    
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Nextup Cobot HMI")
        self.setMinimumSize(1400, 800)
        self.setStyleSheet("""
            QMainWindow {
                background-color: #0a0a1a;
            }
            QMenuBar {
                background-color: #141425;
                color: #a0a0c0;
                border-bottom: 1px solid #2a2a4a;
            }
            QMenuBar::item {
                background-color: transparent;
                padding: 6px 12px;
            }
            QMenuBar::item:selected {
                background-color: #2a2a4a;
                color: #ffffff;
            }
            QMenu {
                background-color: #141425;
                color: #a0a0c0;
                border: 1px solid #2a2a4a;
            }
            QMenu::item:selected {
                background-color: #2a2a4a;
                color: #ffffff;
            }
            QTabWidget::pane {
                background-color: #0a0a1a;
                border: 1px solid #2a2a4a;
                border-radius: 4px;
            }
            QTabBar::tab {
                background-color: #141425;
                color: #a0a0c0;
                padding: 8px 20px;
                margin: 2px;
                border: 1px solid #2a2a4a;
                border-bottom: none;
                border-top-left-radius: 4px;
                border-top-right-radius: 4px;
            }
            QTabBar::tab:selected {
                background-color: #2a2a4a;
                color: #ffffff;
                border-bottom: 2px solid #6a6aae;
            }
            QTabBar::tab:hover {
                background-color: #1a1a3a;
            }
            QLabel {
                color: #c0c0e0;
            }
            QGroupBox {
                color: #6a6aae;
                border: 1px solid #2a2a4a;
                border-radius: 4px;
                margin-top: 10px;
                font-weight: bold;
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                left: 10px;
                padding: 0 5px 0 5px;
            }
            QStatusBar {
                background-color: #0a0a1a;
                color: #8080a0;
                border-top: 1px solid #1a1a3a;
            }
        """)

        # Map display labels to actual joint names
        self.display_to_joint = {
            'J1': 'joint1',
            'J2': 'joint2',
            'J3': 'joint3',
            'J4': 'joint4',
            'J5': 'joint5',
            'J6': 'joint6'
        }
        self.joint_to_display = {v: k for k, v in self.display_to_joint.items()}
        
        self.joint_controls = {}
        self.cartesian_controls = {}
        self.active_motions = {}
        self.viewer = None
        self.servo = None
        self.planner = None
        self.ros_worker = None
        self.current_hover_axis = None
        self.current_hover_direction = None

        self.init_ui()
        self.init_ros()

    def init_ui(self):
        """Initialize the user interface"""
        # Menu
        self.create_menu_bar()
        
        # Central widget
        central = QWidget()
        self.setCentralWidget(central)
        main_layout = QHBoxLayout(central)
        main_layout.setContentsMargins(0, 0, 0, 0)

        # Splitter
        splitter = QSplitter(Qt.Orientation.Horizontal)
        left_panel = self.create_control_panel()
        splitter.addWidget(left_panel)

        self.viewer = Robot3DViewer(self)
        splitter.addWidget(self.viewer)
        splitter.setSizes([400, 1000])
        splitter.setHandleWidth(1)

        main_layout.addWidget(splitter)

        # Connect viewer joint updates to UI
        self.viewer.joint_values_updated.connect(self.update_joint_display)

    def create_menu_bar(self):
        """Create menu bar"""
        menubar = self.menuBar()
        
        # File menu
        file_menu = menubar.addMenu("File")
        exit_action = menubar.addAction("Exit")
        exit_action.setShortcut("Ctrl+Q")
        exit_action.triggered.connect(self.close)
        file_menu.addAction(exit_action)
        
        # View menu
        view_menu = menubar.addMenu("View")
        reset_action = view_menu.addAction("Reset Camera")
        reset_action.setShortcut("R")
        reset_action.triggered.connect(self.reset_camera)
        
        # Safety menu
        safety_menu = menubar.addMenu("Safety")
        stop_action = safety_menu.addAction("Emergency Stop")
        stop_action.setShortcut("Space")
        stop_action.triggered.connect(self.emergency_stop)
        
        # Help menu
        help_menu = menubar.addMenu("Help")
        about_action = help_menu.addAction("About")
        about_action.triggered.connect(self.show_about)

    def create_control_panel(self):
        """Create the left control panel"""
        panel = QWidget()
        panel.setStyleSheet("background-color: #0a0a1a;")
        panel.setFixedWidth(420)
        
        layout = QVBoxLayout(panel)
        layout.setContentsMargins(15, 15, 15, 15)
        layout.setSpacing(15)

        # Title
        title = QLabel("MOTION PLANNING")
        title.setStyleSheet("""
            color: #6a6aae;
            font-size: 18px;
            font-weight: bold;
            letter-spacing: 2px;
            padding: 10px 0;
            border-bottom: 2px solid #2a2a4a;
        """)
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(title)

        # Speed control
        speed_widget = QWidget()
        speed_layout = QHBoxLayout(speed_widget)
        speed_layout.setContentsMargins(5, 10, 5, 10)
        
        speed_label = QLabel("Speed:")
        speed_label.setStyleSheet("color: #a0a0c0; font-size: 12px;")
        speed_layout.addWidget(speed_label)
        
        self.speed_slider = QSlider(Qt.Orientation.Horizontal)
        self.speed_slider.setRange(1, 10)
        self.speed_slider.setValue(5)
        self.speed_slider.setTickInterval(1)
        self.speed_slider.setTickPosition(QSlider.TickPosition.TicksBelow)
        self.speed_slider.setStyleSheet("""
            QSlider::groove:horizontal {
                height: 4px;
                background: #2a2a4a;
                border-radius: 2px;
            }
            QSlider::handle:horizontal {
                background: #6a6aae;
                width: 16px;
                height: 16px;
                margin: -6px 0;
                border-radius: 8px;
            }
            QSlider::sub-page:horizontal {
                background: #6a6aae;
                border-radius: 2px;
            }
        """)
        self.speed_slider.valueChanged.connect(self.update_speed)
        speed_layout.addWidget(self.speed_slider)
        
        self.speed_label = QLabel("0.5x")
        self.speed_label.setStyleSheet("color: #6a6aae; font-weight: bold; font-size: 12px; min-width: 40px;")
        speed_layout.addWidget(self.speed_label)
        layout.addWidget(speed_widget)

        # Tabs
        tabs = QTabWidget()
        tabs.setStyleSheet("""
            QTabWidget::pane {
                background-color: #0f0f22;
                border: 1px solid #2a2a4a;
                border-radius: 4px;
            }
            QTabBar::tab {
                background-color: #141425;
                color: #a0a0c0;
                padding: 6px 15px;
                margin: 0 2px;
                border: 1px solid #2a2a4a;
                border-bottom: none;
                border-top-left-radius: 4px;
                border-top-right-radius: 4px;
            }
            QTabBar::tab:selected {
                background-color: #1a1a3a;
                color: #ffffff;
                border-bottom: 2px solid #6a6aae;
            }
        """)
        
        joint_tab = self.create_joint_tab()
        cart_tab = self.create_cartesian_tab()
        tabs.addTab(joint_tab, "Joints")
        tabs.addTab(cart_tab, "Cartesian")
        layout.addWidget(tabs)

        # E-stop
        estop = QPushButton("⚠ EMERGENCY STOP")
        estop.setStyleSheet("""
            QPushButton {
                background-color: #4a1a1a;
                color: #ff4444;
                border: 2px solid #ff4444;
                border-radius: 8px;
                padding: 12px;
                font-size: 16px;
                font-weight: bold;
                letter-spacing: 2px;
            }
            QPushButton:hover {
                background-color: #6a1a1a;
                border-color: #ff6666;
            }
            QPushButton:pressed {
                background-color: #2a0a0a;
            }
        """)
        estop.clicked.connect(self.emergency_stop)
        layout.addWidget(estop)

        # Status indicator
        status_widget = QWidget()
        status_layout = QHBoxLayout(status_widget)
        status_layout.setContentsMargins(5, 10, 5, 10)
        
        status_dot = QLabel("●")
        status_dot.setStyleSheet("color: #4aee6a; font-size: 12px;")
        status_layout.addWidget(status_dot)
        
        self.status_label = QLabel("Initializing...")
        self.status_label.setStyleSheet("color: #8080a0; font-size: 11px;")
        status_layout.addWidget(self.status_label)
        status_layout.addStretch()
        layout.addWidget(status_widget)

        # Version
        version = QLabel("Nextup Cobot HMI v1.0")
        version.setStyleSheet("color: #404060; font-size: 10px;")
        version.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(version)
        layout.addStretch()

        return panel

    def create_joint_tab(self):
        """Create the joint control tab"""
        tab = QWidget()
        layout = QVBoxLayout(tab)
        layout.setContentsMargins(10, 15, 10, 15)
        layout.setSpacing(8)

        header = QLabel("JOINT POSITIONS")
        header.setStyleSheet("color: #6a6aae; font-weight: bold; font-size: 12px;")
        layout.addWidget(header)

        info = QLabel("Press and hold + or - to move joint")
        info.setStyleSheet("color: #404060; font-size: 10px; font-style: italic;")
        layout.addWidget(info)

        # Use display labels but store with actual joint names
        joint_display_labels = ['J1', 'J2', 'J3', 'J4', 'J5', 'J6']
        joint_names = ['joint1', 'joint2', 'joint3', 'joint4', 'joint5', 'joint6']

        for idx, (display_label, joint_name) in enumerate(zip(joint_display_labels, joint_names)):
            ctrl = JointControlWidget(display_label, idx)
            # Store the actual joint name in the widget
            ctrl.actual_joint_name = joint_name
            ctrl.hover_enter.connect(self.on_joint_hover_enter)
            ctrl.hover_leave.connect(self.on_joint_hover_leave)
            ctrl.joint_velocity.connect(self.on_joint_velocity)
            ctrl.joint_stop.connect(self.on_joint_stop)
            # Store by actual joint name
            self.joint_controls[joint_name] = ctrl
            layout.addWidget(ctrl)

        layout.addStretch()
        return tab

    def create_cartesian_tab(self):
        """Create the Cartesian control tab"""
        tab = QWidget()
        layout = QVBoxLayout(tab)
        layout.setContentsMargins(10, 15, 10, 15)
        layout.setSpacing(8)

        header = QLabel("CARTESIAN SPACE")
        header.setStyleSheet("color: #6a6aae; font-weight: bold; font-size: 12px;")
        layout.addWidget(header)

        info = QLabel("Hover + or - to plan motion" + (" (MoveIt)" if MOVEIT_AVAILABLE else " (disabled)"))
        info.setStyleSheet("color: #404060; font-size: 10px; font-style: italic;")
        layout.addWidget(info)

        # Translation
        trans_group = QGroupBox("Translation")
        trans_layout = QVBoxLayout(trans_group)
        trans_layout.setSpacing(5)
        
        for axis, label in [('x', 'X'), ('y', 'Y'), ('z', 'Z')]:
            ctrl = CartesianControlWidget(axis, label)
            ctrl.hover_enter.connect(self.on_cartesian_hover_enter)
            ctrl.hover_leave.connect(self.on_cartesian_hover_leave)
            self.cartesian_controls[axis] = ctrl
            trans_layout.addWidget(ctrl)
        layout.addWidget(trans_group)

        # Rotation
        rot_group = QGroupBox("Rotation")
        rot_layout = QVBoxLayout(rot_group)
        rot_layout.setSpacing(5)
        
        for axis, label in [('roll', 'Roll'), ('pitch', 'Pitch'), ('yaw', 'Yaw')]:
            ctrl = CartesianControlWidget(axis, label)
            ctrl.hover_enter.connect(self.on_cartesian_hover_enter)
            ctrl.hover_leave.connect(self.on_cartesian_hover_leave)
            self.cartesian_controls[axis] = ctrl
            rot_layout.addWidget(ctrl)
        layout.addWidget(rot_group)

        layout.addStretch()
        return tab

    def init_ros(self):
        """Initialize ROS2 worker"""
        self.ros_worker = RosWorker()
        self.ros_worker.node_initialized.connect(self.on_node_ready)
        self.ros_worker.start()
        self.status_label.setText("Connecting to ROS...")

    def on_node_ready(self, node):
        """Called when ROS node is ready"""
        # Setup servo publisher
        self.servo = ServoController(node)
        self.status_label.setText("Connected - Servo Active")

        # Setup MoveIt planner if available
        if MOVEIT_AVAILABLE:
            try:
                self.planner = MoveItPlanner(node, group='robot_manipulator')
                if self.planner.available:
                    self.planner.planning_done.connect(self.on_planning_done)
                    self.planner.trajectory_ready.connect(self.on_trajectory_ready)
                    self.planner.progress_update.connect(self.on_planning_progress)
                    self.status_label.setText("Connected - Servo & Planning Active")
                else:
                    self.status_label.setText("Connected - Servo Active (Planning disabled)")
            except Exception as e:
                print(f"MoveIt init error: {e}")
                self.status_label.setText("Connected - Servo Active (Planning error)")
        else:
            self.status_label.setText("Connected - Servo Active (MoveIt not installed)")

        # Setup TF in viewer
        self.viewer.setup_tf(node)
        print("✓ ROS2 initialized")

    def on_joint_hover_enter(self, display_name, direction):
        """Handle hover entering joint button"""
        # Convert display name to actual joint name if needed
        joint_name = self.display_to_joint.get(display_name, display_name)
        if self.viewer:
            self.viewer.show_joint_arrow(joint_name, direction)
        direction_text = '+' if direction == 'plus' else '-'
        self.statusBar().showMessage(f"Joint {display_name} - {direction_text}")

    def on_joint_hover_leave(self, display_name):
        """Handle hover leaving joint button"""
        if self.viewer:
            self.viewer.hide_all_arrows()
        self.statusBar().showMessage("Ready")

    def on_joint_velocity(self, display_name, velocity):
        """Handle joint velocity command"""
        if not self.servo:
            return
        
        # Get actual joint name from display name
        joint_name = self.display_to_joint.get(display_name, display_name)
        
        if joint_name not in self.joint_controls:
            print(f"⚠ Unknown joint: {joint_name}")
            return
            
        idx = self.joint_controls[joint_name].joint_index
        self.servo.publish_joint_velocity(idx, velocity)
        
        # Start timer for continuous motion
        if joint_name in self.active_motions:
            self.active_motions[joint_name].stop()
            self.active_motions[joint_name].deleteLater()
        
        timer = QTimer()
        timer.setInterval(50)
        timer.timeout.connect(lambda: self.servo.publish_joint_velocity(idx, velocity))
        timer.start()
        self.active_motions[joint_name] = timer

    def on_joint_stop(self, display_name):
        """Handle joint stop"""
        # Get actual joint name from display name
        joint_name = self.display_to_joint.get(display_name, display_name)
        
        if joint_name in self.active_motions:
            self.active_motions[joint_name].stop()
            self.active_motions[joint_name].deleteLater()
            del self.active_motions[joint_name]
        
        if self.servo and joint_name in self.joint_controls:
            idx = self.joint_controls[joint_name].joint_index
            self.servo.publish_joint_velocity(idx, 0.0)

    def on_cartesian_hover_enter(self, axis, direction):
        """Handle hover entering Cartesian button - triggers planning"""
        if not self.planner or not self.planner.available:
            self.statusBar().showMessage("MoveIt planning not available")
            return
            
        self.current_hover_axis = axis
        self.current_hover_direction = direction
            
        # Determine offset
        offset = 0.1 if axis in ['x', 'y', 'z'] else 0.2  # 10cm or 0.2 rad
        if direction == 'minus':
            offset = -offset
            
        # Start planning
        self.planner.plan_cartesian_offset(axis, offset)
        direction_text = '+' if direction == 'plus' else '-'
        self.statusBar().showMessage(f"Planning {axis} {direction_text} offset...")

    def on_cartesian_hover_leave(self, axis):
        """Handle hover leaving Cartesian button"""
        self.current_hover_axis = None
        self.current_hover_direction = None
        if self.viewer:
            self.viewer.clear_ghost()
        self.statusBar().showMessage("Ready")

    def on_trajectory_ready(self, display_trajectory, axis, direction):
        """Called when a trajectory planning request succeeds"""
        if self.current_hover_axis == axis and self.current_hover_direction == direction:
            if self.viewer:
                self.viewer.show_ghost_trajectory(display_trajectory)

    def on_planning_done(self, success, message):
        """Handle planning completion"""
        if success:
            self.statusBar().showMessage(f"✓ {message}")
        else:
            self.statusBar().showMessage(f"✗ {message}")
            # A failed plan never reaches on_trajectory_ready, so without
            # this the ghost from whatever hover last SUCCEEDED just stays
            # on screen — looking exactly like the failed request silently
            # reused old/cached data, when really nothing new ever arrived.
            if self.viewer:
                self.viewer.clear_ghost()

    def on_planning_progress(self, progress):
        """Handle planning progress update"""
        pass  # Could update a progress bar

    def update_speed(self, value):
        """Update speed multiplier"""
        speed = value / 10.0
        self.speed_label.setText(f"{speed:.1f}x")
        for ctrl in self.joint_controls.values():
            ctrl.velocity = 0.2 * speed

    def update_joint_display(self, joint_names, positions):
        """Update joint value displays"""
        for name, pos in zip(joint_names, positions):
            if name in self.joint_controls:
                self.joint_controls[name].update_value(pos)

    def reset_camera(self):
        """Reset 3D camera view"""
        if self.viewer:
            self.viewer.reset_camera()

    def emergency_stop(self):
        """Emergency stop"""
        # Stop all joint timers
        for timer in self.active_motions.values():
            timer.stop()
            timer.deleteLater()
        self.active_motions.clear()
        
        # Send zero velocity to all joints
        if self.servo:
            for idx in range(6):
                self.servo.publish_joint_velocity(idx, 0.0)
        
        self.statusBar().showMessage("⚠ EMERGENCY STOP")
        QMessageBox.warning(self, "Emergency Stop", "All joints have been stopped!")

    def show_about(self):
        """Show about dialog"""
        QMessageBox.about(self, "About Nextup Cobot HMI",
            "<h2>Nextup Cobot HMI</h2>"
            "<p>Version 1.0</p>"
            "<p>Robot control with MoveIt planning</p>"
            "<p>© Nextup Robotics</p>"
        )

    def closeEvent(self, event):
        """Handle close event"""
        self.emergency_stop()
        if self.ros_worker:
            self.ros_worker.stop()
            self.ros_worker.wait()
        event.accept()