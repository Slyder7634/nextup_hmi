from geometry_msgs.msg import Twist, TwistStamped
from std_msgs.msg import Float64MultiArray
import rclpy
from rclpy.node import Node

class ServoController:
    def __init__(self, node: Node):
        self.node = node
        # For joint velocity commands: /servo_node/delta_joint_cmds
        self.joint_pub = node.create_publisher(
            Float64MultiArray,
            '/servo_node/delta_joint_cmds',
            10
        )
        # For Cartesian velocity commands: /servo_node/delta_twist_cmds
        self.twist_pub = node.create_publisher(
            TwistStamped,
            '/servo_node/delta_twist_cmds',
            10
        )
        self.joint_names = ['joint1','joint2','joint3','joint4','joint5','joint6']

    def publish_joint_velocity(self, joint_index, velocity):
        """Send joint velocity command (rad/s) for a single joint."""
        msg = Float64MultiArray()
        msg.data = [0.0] * len(self.joint_names)
        msg.data[joint_index] = velocity
        self.joint_pub.publish(msg)
        print(f"📤 Joint {joint_index} velocity: {velocity:.2f}")

    def publish_twist(self, linear=(0,0,0), angular=(0,0,0)):
        """Send Cartesian velocity command (m/s, rad/s) in base frame."""
        msg = TwistStamped()
        msg.header.stamp = self.node.get_clock().now().to_msg()
        msg.header.frame_id = 'base_link'
        msg.twist.linear.x = linear[0]
        msg.twist.linear.y = linear[1]
        msg.twist.linear.z = linear[2]
        msg.twist.angular.x = angular[0]
        msg.twist.angular.y = angular[1]
        msg.twist.angular.z = angular[2]
        self.twist_pub.publish(msg)
        print(f"📤 Twist: linear={linear}, angular={angular}")