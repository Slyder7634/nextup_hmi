#!/bin/bash
# Launches the Nextup Cobot HMI.
# Assumes ROS2 and this robot's workspaces are already installed on this
# machine (same prerequisites as the original dev PC). This script does not
# install anything - it just sources the environment and starts the app.

set -e
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

require() {
    if [ ! -f "$1" ]; then
        echo "ERROR: expected setup file not found: $1"
        echo "This machine is missing a required ROS2 workspace. Build/install it first."
        exit 1
    fi
    source "$1"
}

require /opt/ros/humble/setup.bash
require ~/nextup_controllers/install/setup.bash
require ~/x_cat/install/setup.bash
require ~/NextupRobot/install/setup.bash

echo "Starting robot..."

ros2 launch simulation_nextup_moveit_config everything.launch.py rviz:=false \
    > /tmp/robot_launch.log 2>&1 &

LAUNCH_PID=$!

sleep 5

ros2 service call /servo_node/start_servo std_srvs/srv/Trigger "{}"

echo "Starting HMI..."

python3 main.py

# Kill launch when HMI exits
kill "$LAUNCH_PID" 2>/dev/null || true
