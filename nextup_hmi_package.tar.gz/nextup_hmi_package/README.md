# Nextup Cobot HMI - install package

## Prerequisites on the target PC

This package only copies and launches the app - it does **not** install
ROS2, Python packages, or the robot workspaces. The target machine needs:

- ROS2 Humble
- The robot workspaces built and installed at:
  - `~/nextup_controllers`
  - `~/x_cat`
  - `~/NextupRobot`
- Python3 with `PyQt6`, `vtk`, and `rclpy` available (whatever environment
  you normally run the HMI in)

If any of these are missing, `run.sh` will stop with a clear error telling
you which one.

## Install

1. Copy this whole folder (or the `.tar.gz`) to the target PC.
2. From inside it, run:
   ```bash
   ./install.sh
   ```
   This copies the app (including the URDF and mesh files) to
   `~/.local/share/nextup_hmi` and creates a `nextup-hmi` command plus an
   entry in the applications menu.

## Run

```bash
nextup-hmi
```

or launch "Nextup Cobot HMI" from your applications menu.

## Updating later

Re-run `./install.sh` from a newer copy of this package - it just
overwrites `~/.local/share/nextup_hmi`.

## Uninstall

```bash
rm -rf ~/.local/share/nextup_hmi
rm ~/.local/bin/nextup-hmi
rm ~/.local/share/applications/nextup-hmi.desktop
```
