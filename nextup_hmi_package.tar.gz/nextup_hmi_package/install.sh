#!/bin/bash
# Installer for the Nextup Cobot HMI.
# Copies the app to ~/.local/share/nextup_hmi and creates a "nextup-hmi"
# launch command plus an entry in the applications menu.
#
# Prerequisites (must already be on this PC - not installed by this script):
#   - ROS2 Humble
#   - This robot's workspaces: ~/nextup_controllers, ~/x_cat, ~/NextupRobot
#   - Python3 with PyQt6, vtk, rclpy (same Python env used to run the app before)

set -e

APP_NAME="nextup_hmi"
INSTALL_DIR="$HOME/.local/share/${APP_NAME}"
BIN_DIR="$HOME/.local/bin"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "Installing Nextup Cobot HMI to ${INSTALL_DIR} ..."
mkdir -p "$INSTALL_DIR"
cp -r "$SCRIPT_DIR"/app/. "$INSTALL_DIR"/
chmod +x "$INSTALL_DIR/run.sh"

mkdir -p "$BIN_DIR"
cat > "$BIN_DIR/nextup-hmi" << EOF
#!/bin/bash
cd "$INSTALL_DIR"
exec ./run.sh "\$@"
EOF
chmod +x "$BIN_DIR/nextup-hmi"

DESKTOP_DIR="$HOME/.local/share/applications"
mkdir -p "$DESKTOP_DIR"
cat > "$DESKTOP_DIR/nextup-hmi.desktop" << EOF
[Desktop Entry]
Type=Application
Name=Nextup Cobot HMI
Comment=Robot arm control HMI
Exec=$BIN_DIR/nextup-hmi
Terminal=true
Categories=Utility;Development;
EOF

echo ""
echo "Install complete."
echo ""

case ":$PATH:" in
    *":$BIN_DIR:"*) ;;
    *)
        echo "NOTE: $BIN_DIR is not on your PATH."
        echo "      Add this to ~/.bashrc, then open a new terminal:"
        echo "        export PATH=\"\$HOME/.local/bin:\$PATH\""
        ;;
esac

echo "Run it with:  nextup-hmi"
echo "...or find 'Nextup Cobot HMI' in your applications menu."
