"""
MoveIt Planner for Nextup Cobot HMI
"""
import rclpy
from rclpy.node import Node
from rclpy.callback_groups import MutuallyExclusiveCallbackGroup, ReentrantCallbackGroup
from PyQt6.QtCore import QObject, pyqtSignal
import math
import time

try:
    from moveit_msgs.srv import GetPositionFK, GetPlanningScene, GetMotionPlan
    from moveit_msgs.msg import RobotState, DisplayTrajectory, PlanningScene
    from geometry_msgs.msg import Pose
    from shape_msgs.msg import SolidPrimitive
    MOVEIT_AVAILABLE = True
except ImportError:
    MOVEIT_AVAILABLE = False
    print("⚠ MoveIt not available")
class MoveItPlanner(QObject):
    planning_done = pyqtSignal(bool, str)
    trajectory_ready = pyqtSignal(object, str, str)  # Emits (display_trajectory, axis, direction)
    progress_update = pyqtSignal(float)
    
    def __init__(self, node: Node = None, group='manipulator', ee_link='link6'):
        super().__init__()
        self.node = node
        self.group = group
        self.ee_link = ee_link
        self.available = False
        self._current_plan_id = 0
        
        if not MOVEIT_AVAILABLE:
            print("⚠ MoveIt planning unavailable")
            return
            
        if node is None:
            print("⚠ No ROS node provided")
            return
            
        self.available = True
        
        try:
            # Use separate callback groups for each client to avoid conflicts
            self.plan_group = MutuallyExclusiveCallbackGroup()
            self.fk_group = MutuallyExclusiveCallbackGroup()
            self.scene_group = MutuallyExclusiveCallbackGroup()
            
            # Create service clients with their own callback groups
            self.plan_client = node.create_client(
                GetMotionPlan, 
                '/plan_kinematic_path',
                callback_group=self.plan_group
            )
            self.fk_client = node.create_client(
                GetPositionFK,
                '/compute_fk',
                callback_group=self.fk_group
            )
            self.scene_client = node.create_client(
                GetPlanningScene,
                '/get_planning_scene',
                callback_group=self.scene_group
            )
            
            # Publisher (doesn't need a callback group)
            self.display_pub = node.create_publisher(
                DisplayTrajectory,
                '/display_planned_path',
                10
            )
            
            print("✓ MoveIt planner initialized")
        except Exception as e:
            print(f"⚠ MoveIt init error: {e}")
            self.available = False

    def plan_cartesian_offset(self, direction, offset):
        if not self.available:
            self.planning_done.emit(False, "MoveIt not available")
            return
            
        self._current_plan_id += 1
        plan_id = self._current_plan_id
        
        import threading
        threading.Thread(
            target=self._plan_cartesian_offset_thread,
            args=(direction, offset, plan_id),
            daemon=True
        ).start()

    def _plan_cartesian_offset_thread(self, direction, offset, plan_id):
        try:
            self.progress_update.emit(10.0)
            
            state = self._get_current_state(plan_id)
            if plan_id != self._current_plan_id:
                return
            if not state:
                self.planning_done.emit(False, "Failed to get current robot state")
                return
                
            self.progress_update.emit(30.0)
            
            pose = self._get_current_pose(state, plan_id)
            if plan_id != self._current_plan_id:
                return
            if not pose:
                self.planning_done.emit(False, "Failed to get current pose")
                return
                
            self.progress_update.emit(50.0)
            
            target_pose = self._apply_offset(pose, direction, offset)
            
            self.progress_update.emit(70.0)
            
            traj = self._plan_to_pose(target_pose, state, plan_id)
            if plan_id != self._current_plan_id:
                return
            if traj is None:
                self.planning_done.emit(False, "Planning failed")
                return
                
            self.progress_update.emit(90.0)
            
            display = DisplayTrajectory()
            display.trajectory.append(traj)
            display.model_states = self._build_model_states(traj)
            self.display_pub.publish(display)
            
            dir_sign = 'plus' if offset > 0 else 'minus'
            self.trajectory_ready.emit(display, direction, dir_sign)
            self.progress_update.emit(100.0)
            self.planning_done.emit(True, f"Planned {direction} offset of {offset:.3f}")
            
        except Exception as e:
            if plan_id == self._current_plan_id:
                self.planning_done.emit(False, f"Planning error: {e}")

    def _get_current_state(self, plan_id):
        try:
            req = GetPlanningScene.Request()
            req.components.components = 1  # SCENE_STATE
            
            future = self.scene_client.call_async(req)
            import time
            end_time = time.time() + 2.0
            while not future.done() and time.time() < end_time:
                if plan_id != self._current_plan_id:
                    return None
                time.sleep(0.01)
                
            if future.done():
                response = future.result()
                if response and response.scene:
                    return response.scene.robot_state
            return None
        except Exception as e:
            print(f"Error getting state: {e}")
            return None

    def _get_current_pose(self, state, plan_id):
        try:
            req = GetPositionFK.Request()
            req.robot_state = state
            req.fk_link_names = [self.ee_link]
            req.header.frame_id = 'base_link'
            req.header.stamp = self.node.get_clock().now().to_msg()
            
            future = self.fk_client.call_async(req)
            import time
            end_time = time.time() + 2.0
            while not future.done() and time.time() < end_time:
                if plan_id != self._current_plan_id:
                    return None
                time.sleep(0.01)
                
            if future.done():
                response = future.result()
                if response and response.pose_stamped:
                    return response.pose_stamped[0].pose
            return None
        except Exception as e:
            print(f"Error getting pose: {e}")
            return None

    def _apply_offset(self, pose, direction, offset):
        target = Pose()
        target.position.x = pose.position.x
        target.position.y = pose.position.y
        target.position.z = pose.position.z
        target.orientation = pose.orientation

        if direction == 'x':
            target.position.x += offset
        elif direction == 'y':
            target.position.y += offset
        elif direction == 'z':
            target.position.z += offset
        elif direction in ['roll', 'pitch', 'yaw']:
            euler = self._quat_to_euler(pose.orientation)
            if direction == 'roll':
                euler[0] += offset
            elif direction == 'pitch':
                euler[1] += offset
            elif direction == 'yaw':
                euler[2] += offset
            q = self._euler_to_quat(euler[0], euler[1], euler[2])
            target.orientation.x = q[0]
            target.orientation.y = q[1]
            target.orientation.z = q[2]
            target.orientation.w = q[3]
            
        return target

    def _plan_to_pose(self, target_pose, start_state, plan_id):
        try:
            req = GetMotionPlan.Request()
            req.motion_plan_request.group_name = self.group
            req.motion_plan_request.start_state = start_state
            
            # Add constraints
            from moveit_msgs.msg import Constraints, PositionConstraint, OrientationConstraint
            from shape_msgs.msg import SolidPrimitive
            
            req.motion_plan_request.num_planning_attempts = 5
            req.motion_plan_request.allowed_planning_time = 5.0
            
            # Position constraint
            pc = PositionConstraint()
            pc.header.frame_id = 'base_link'
            pc.link_name = self.ee_link
            pc.target_point_offset.x = 0.0
            pc.target_point_offset.y = 0.0
            pc.target_point_offset.z = 0.0
            
            # A sphere region centered at the target pose
            primitive = SolidPrimitive()
            primitive.type = SolidPrimitive.SPHERE
            primitive.dimensions = [0.01]  # 1cm tolerance radius
            
            pc.constraint_region.primitives.append(primitive)
            pc.constraint_region.primitive_poses.append(target_pose)
            
            # Orientation constraint
            oc = OrientationConstraint()
            oc.header.frame_id = 'base_link'
            oc.link_name = self.ee_link
            oc.orientation = target_pose.orientation
            oc.absolute_x_axis_tolerance = 0.05
            oc.absolute_y_axis_tolerance = 0.05
            oc.absolute_z_axis_tolerance = 0.05
            oc.weight = 1.0
            
            # Combine into a single Constraints msg
            c = Constraints()
            c.position_constraints.append(pc)
            c.orientation_constraints.append(oc)
            
            # Append it to the list of goal constraints
            req.motion_plan_request.goal_constraints.append(c)
            
            future = self.plan_client.call_async(req)
            import time
            end_time = time.time() + 10.0
            while not future.done() and time.time() < end_time:
                if plan_id != self._current_plan_id:
                    return None
                time.sleep(0.01)
                
            if future.done():
                response = future.result()
                if response and response.trajectory:
                    return response.trajectory
            return None
        except Exception as e:
            print(f"Planning error: {e}")
            return None

    def _build_model_states(self, traj):
        states = []
        if not traj.joint_trajectory:
            return states
        for pt in traj.joint_trajectory.points:
            s = RobotState()
            s.joint_state.name = traj.joint_trajectory.joint_names
            s.joint_state.position = pt.positions
            if pt.velocities:
                s.joint_state.velocity = pt.velocities
            else:
                s.joint_state.velocity = [0.0] * len(s.joint_state.name)
            states.append(s)
        return states

    def _quat_to_euler(self, q):
        sinr_cosp = 2 * (q.w * q.x + q.y * q.z)
        cosr_cosp = 1 - 2 * (q.x * q.x + q.y * q.y)
        roll = math.atan2(sinr_cosp, cosr_cosp)
        
        sinp = 2 * (q.w * q.y - q.z * q.x)
        if abs(sinp) >= 1:
            pitch = math.copysign(math.pi / 2, sinp)
        else:
            pitch = math.asin(sinp)
        
        siny_cosp = 2 * (q.w * q.z + q.x * q.y)
        cosy_cosp = 1 - 2 * (q.y * q.y + q.z * q.z)
        yaw = math.atan2(siny_cosp, cosy_cosp)
        return [roll, pitch, yaw]

    def _euler_to_quat(self, roll, pitch, yaw):
        cy = math.cos(yaw * 0.5)
        sy = math.sin(yaw * 0.5)
        cp = math.cos(pitch * 0.5)
        sp = math.sin(pitch * 0.5)
        cr = math.cos(roll * 0.5)
        sr = math.sin(roll * 0.5)
        qw = cr * cp * cy + sr * sp * sy
        qx = sr * cp * cy - cr * sp * sy
        qy = cr * sp * cy + sr * cp * sy
        qz = cr * cp * sy - sr * sp * cy
        return (qx, qy, qz, qw)