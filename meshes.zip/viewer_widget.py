"""
VTK 3D Robot Viewer for Nextup Cobot HMI
"""
import os
import math
import sys
from PyQt6.QtWidgets import QWidget, QVBoxLayout, QSizePolicy
from PyQt6.QtCore import QTimer, pyqtSignal
import rclpy
from geometry_msgs.msg import TransformStamped

try:
    import vtk
    from vtk.qt.QVTKRenderWindowInteractor import QVTKRenderWindowInteractor
    VTK_AVAILABLE = True
except ImportError:
    VTK_AVAILABLE = False
    print("Error: VTK not installed")

try:
    import tf2_ros
    from tf2_ros import TransformException
    ROS2_AVAILABLE = True
except ImportError:
    ROS2_AVAILABLE = False

from urdf_parser import URDFParser


class Robot3DViewer(QWidget):
    """VTK-based 3D robot visualization widget"""
    
    joint_values_updated = pyqtSignal(list, list)
    
    def __init__(self, parent=None, urdf_path=None, mesh_path=None):
        super().__init__(parent)
        
        script_dir = os.path.dirname(os.path.abspath(__file__))
        
        # Find URDF
        if urdf_path is None:
            candidates = [
                os.path.join(script_dir, "nextupCobot.urdf.xacro"),
                os.path.join(script_dir, "nextupCobot.urdf"),
                os.path.expanduser("~/nextup_cobot_ws/src/nextup_moveit_config/urdf/nextupCobot.urdf.xacro"),
            ]
            for c in candidates:
                if os.path.exists(c):
                    urdf_path = c
                    break
        
        self.urdf_path = urdf_path
        self.mesh_path = mesh_path or os.path.join(script_dir, "meshes/")
        self.urdf_parser = URDFParser(self.urdf_path)
        print(self.urdf_parser.links.keys())
        # Real robot actors
        self.link_actors = {}
        self.link_transforms = {}
        self.link_colors = {}
        self.link_original_colors = {}
        self.link_names = []
        
        # Ghost robot actors
        self.ghost_actors = []
        self.ghost_link_actors = {}
        self.ghost_visible = False
        self.ghost_waypoints = []
        
        # Joint arrows
        self.joint_arrows = {}
        self.joint_arrow_visible = {}
        
        # TF
        self.tf_buffer = None
        self.tf_listener = None
        self.tf_initialized = False
        
        # Setup VTK
        self.setup_vtk()
        self.load_robot_meshes()
        self.setup_camera()
        self.create_joint_arrows()
        
        # Timer for TF updates
        self.update_timer = QTimer()
        self.update_timer.setInterval(50)  # 20 Hz
        self.update_timer.timeout.connect(self.update_from_tf)
        self.update_timer.start()
        
        print(f"✓ Robot3DViewer initialized")
        print(f"  URDF: {self.urdf_path}")
        print(f"  Mesh path: {self.mesh_path}")
        print(f"  Links: {list(self.link_actors.keys())}")
    
    def setup_vtk(self):
        """Initialize VTK renderer and widget"""
        self.vtk_widget = QVTKRenderWindowInteractor(self)
        self.vtk_widget.setSizePolicy(QSizePolicy.Policy.Expanding, 
                                     QSizePolicy.Policy.Expanding)
        
        self.renderer = vtk.vtkRenderer()
        self.renderer.SetBackground(0.05, 0.05, 0.1)
        
        self.setup_lighting()
        self.vtk_widget.GetRenderWindow().AddRenderer(self.renderer)
        
        self.interactor = self.vtk_widget.GetRenderWindow().GetInteractor()
        self.interactor.SetInteractorStyle(vtk.vtkInteractorStyleTrackballCamera())
        
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(self.vtk_widget)
    
    def setup_lighting(self):
        """Setup lighting for the scene"""
        ambient = vtk.vtkLight()
        ambient.SetColor(0.4, 0.4, 0.4)
        ambient.SetIntensity(0.3)
        self.renderer.AddLight(ambient)
        
        light = vtk.vtkLight()
        light.SetPosition(2.5, -1.5, 2.0)
        light.SetFocalPoint(0, 0.2, 0.4)
        light.SetColor(1.0, 1.0, 1.0)
        light.SetIntensity(1.0)
        light.SetLightTypeToSceneLight()
        self.renderer.AddLight(light)
        
        fill = vtk.vtkLight()
        fill.SetPosition(-2.5, 1.5, 1.0)
        fill.SetFocalPoint(0, 0.2, 0.4)
        fill.SetColor(0.6, 0.6, 0.8)
        fill.SetIntensity(0.5)
        fill.SetLightTypeToSceneLight()
        self.renderer.AddLight(fill)
        
        back = vtk.vtkLight()
        back.SetPosition(0, 0.5, -2.0)
        back.SetFocalPoint(0, 0.2, 0.4)
        back.SetColor(0.4, 0.4, 0.6)
        back.SetIntensity(0.3)
        back.SetLightTypeToSceneLight()
        self.renderer.AddLight(back)
    
    def setup_camera(self):
        """Setup default camera position"""
        camera = self.renderer.GetActiveCamera()
        camera.SetFocalPoint(0.0, 0.0, 0.2)
        camera.SetPosition(0.0, -2.5, 0.8)
        camera.SetViewUp(0, 0, 1)
        self.renderer.ResetCameraClippingRange()
        self.add_floor_grid()
    
    def reset_camera(self):
        """Reset camera to default position"""
        camera = self.renderer.GetActiveCamera()
        camera.SetFocalPoint(0.0, 0.0, 0.2)
        camera.SetPosition(0.0, -2.5, 0.8)
        camera.SetViewUp(0, 0, 1)
        self.renderer.ResetCameraClippingRange()
        self.vtk_widget.GetRenderWindow().Render()
    
    def add_floor_grid(self):
        """Add a grid floor"""
        grid_source = vtk.vtkPlaneSource()
        grid_source.SetOrigin(-2.0, -2.0, 0.0)
        grid_source.SetPoint1(2.0, -2.0, 0.0)
        grid_source.SetPoint2(-2.0, 2.0, 0.0)
        grid_source.SetXResolution(20)
        grid_source.SetYResolution(20)
        
        grid_mapper = vtk.vtkPolyDataMapper()
        grid_mapper.SetInputConnection(grid_source.GetOutputPort())
        
        grid_actor = vtk.vtkActor()
        grid_actor.SetMapper(grid_mapper)
        grid_actor.GetProperty().SetColor(0.3, 0.3, 0.4)
        grid_actor.GetProperty().SetOpacity(0.5)
        grid_actor.GetProperty().SetRepresentationToWireframe()
        
        self.renderer.AddActor(grid_actor)
    
    def load_robot_meshes(self):
        """Load robot meshes from URDF or defaults"""
        print("Loading robot meshes...")
        
        # Get mesh filenames from URDF
        if self.urdf_parser.link_meshes:
            link_meshes = self.urdf_parser.link_meshes
        else:
            link_meshes = {
                'base_link': 'base_link.STL',
                'Link1': 'Link1.STL',
                'Link2': 'Link2.STL',
                'Link3': 'Link3.STL',
                'Link4': 'Link4.STL',
                'Link5': 'Link5.STL',
                'Link6': 'Link6.STL',
            }
        
        # Map to actual link names from URDF
        # The URDF might use different capitalization
        link_name_map = {}
        for link in self.urdf_parser.links.keys():
            link_lower = link.lower()
            for mesh_link in link_meshes.keys():
                if mesh_link.lower() == link_lower:
                    link_name_map[link] = mesh_link
                    break
        
        colors = {
            'base_link': (0.4, 0.4, 0.5),
            'Link1': (0.5, 0.6, 0.7),
            'Link2': (0.6, 0.7, 0.8),
            'Link3': (0.65, 0.75, 0.85),
            'Link4': (0.7, 0.8, 0.9),
            'Link5': (0.75, 0.82, 0.92),
            'Link6': (0.8, 0.85, 0.95),
        }
        
        # Load meshes for all links in URDF
        for link_name in self.urdf_parser.link_meshes.keys():
            if link_name in ["world", "ground_link", "end"]:
                continue
            # Find matching mesh file
            mesh_file = None
            for mesh_link, mesh_file_name in link_meshes.items():
                if mesh_link.lower() == link_name.lower():
                    mesh_file = mesh_file_name
                    break
            
            if mesh_file is None:
                # Try to find by name
                for mesh_link, mesh_file_name in link_meshes.items():
                    if link_name.lower() in mesh_link.lower() or mesh_link.lower() in link_name.lower():
                        mesh_file = mesh_file_name
                        break
            
            if mesh_file is None:
                print(f"  ⚠ No mesh found for {link_name}, using default")
                mesh_file = 'base_link.STL'
            
            color = colors.get(link_name, (0.7, 0.7, 0.8))
            if link_name not in colors:
                # Try case-insensitive match
                for key in colors:
                    if key.lower() == link_name.lower():
                        color = colors[key]
                        break
            
            self.link_colors[link_name] = color
            self.link_original_colors[link_name] = color
            print(f"{link_name} ---> {mesh_file}")
            actor = self._load_mesh(mesh_file, color)
            self.link_actors[link_name] = actor
            self.link_names.append(link_name)
            self.renderer.AddActor(actor)
            
            # Identity transform initially
            transform = vtk.vtkTransform()
            transform.Identity()
            self.link_transforms[link_name] = transform
            actor.SetUserTransform(transform)
            
            print(f"  Loaded {link_name} -> {mesh_file}")
        
        print(f"✓ Loaded {len(self.link_actors)} link meshes")
        
        # Create ghost actors by sharing mappers
        for link_name, actor in self.link_actors.items():
            ghost_actor = vtk.vtkActor()
            ghost_actor.SetMapper(actor.GetMapper())
            ghost_actor.GetProperty().SetColor(0.0, 0.8, 0.8) # Cyan ghost
            ghost_actor.GetProperty().SetOpacity(0.4)
            ghost_actor.GetProperty().SetSpecular(0.1)
            ghost_actor.SetVisibility(False)
            self.renderer.AddActor(ghost_actor)
            self.ghost_link_actors[link_name] = ghost_actor
    
    def _load_mesh(self, mesh_filename, color):
        """Load a mesh file"""
        try:
            # Try multiple paths with different cases
            mesh_paths = [
                os.path.join(self.mesh_path, mesh_filename),
                os.path.join(self.mesh_path, mesh_filename.lower()),
                os.path.join(self.mesh_path, mesh_filename.upper()),
                os.path.join(self.mesh_path, mesh_filename.capitalize()),
                mesh_filename,
            ]
            
            for path in mesh_paths:
                if os.path.exists(path):
                    print(f"    Found mesh: {path}")
                    if path.lower().endswith('.stl'):
                        reader = vtk.vtkSTLReader()
                        reader.SetFileName(path)
                        mapper = vtk.vtkPolyDataMapper()
                        mapper.SetInputConnection(reader.GetOutputPort())
                        actor = vtk.vtkActor()
                        actor.SetMapper(mapper)
                        actor.GetProperty().SetColor(color)
                        actor.GetProperty().SetSpecular(0.3)
                        actor.GetProperty().SetSpecularPower(20)
                        return actor
                    elif path.lower().endswith('.obj'):
                        reader = vtk.vtkOBJReader()
                        reader.SetFileName(path)
                        mapper = vtk.vtkPolyDataMapper()
                        mapper.SetInputConnection(reader.GetOutputPort())
                        actor = vtk.vtkActor()
                        actor.SetMapper(mapper)
                        actor.GetProperty().SetColor(color)
                        actor.GetProperty().SetSpecular(0.3)
                        actor.GetProperty().SetSpecularPower(20)
                        return actor
            
            # Fallback: create a box
            print(f"    ⚠ Mesh not found: {mesh_filename}, using placeholder")
            source = vtk.vtkCubeSource()
            source.SetXLength(0.05)
            source.SetYLength(0.05)
            source.SetZLength(0.05)
            mapper = vtk.vtkPolyDataMapper()
            mapper.SetInputConnection(source.GetOutputPort())
            actor = vtk.vtkActor()
            actor.SetMapper(mapper)
            actor.GetProperty().SetColor(color)
            return actor
            
        except Exception as e:
            print(f"    ⚠ Error loading mesh {mesh_filename}: {e}")
            source = vtk.vtkSphereSource()
            source.SetRadius(0.03)
            mapper = vtk.vtkPolyDataMapper()
            mapper.SetInputConnection(source.GetOutputPort())
            actor = vtk.vtkActor()
            actor.SetMapper(mapper)
            actor.GetProperty().SetColor(color)
            return actor
    
    def create_joint_arrows(self):
        """Create arrows for joint visualization"""
        # Joint 1: Circular arrows
        joint1_pos = self.urdf_parser.get_joint_origin('joint1')
        base_x, base_y, base_z = joint1_pos[0] if joint1_pos else 0, joint1_pos[1] if len(joint1_pos) > 1 else 0, 0.0
        
        # CCW arrow (green, for +)
        self.joint1_ccw = self._create_circular_arrow(False, base_x, base_y - 0.5, base_z)
        self.joint1_ccw.GetProperty().SetColor(0.0, 0.8, 0.0)
        self.joint1_ccw.SetVisibility(False)
        self.renderer.AddActor(self.joint1_ccw)
        
        # CW arrow (red, for -)
        self.joint1_cw = self._create_circular_arrow(True, base_x, base_y + 0.5, base_z)
        self.joint1_cw.GetProperty().SetColor(0.8, 0.0, 0.0)
        self.joint1_cw.SetVisibility(False)
        self.renderer.AddActor(self.joint1_cw)
        
        self.joint_arrows['joint1'] = {'plus': self.joint1_ccw, 'minus': self.joint1_cw}
        
        # Joints 2, 3, 4: Straight arrows
        for joint_name in ['joint2', 'joint3', 'joint4']:
            self._create_static_arrow(joint_name)
    
    def _create_circular_arrow(self, clockwise, cx, cy, cz):
        """Create a circular arrow"""
        points = vtk.vtkPoints()
        lines = vtk.vtkCellArray()
        
        num_segments = 30
        radius = 0.3
        
        if clockwise:
            start = 0
            end = -2 * math.pi * 0.75
            step = (end - start) / num_segments
        else:
            start = 0
            end = 2 * math.pi * 0.75
            step = (end - start) / num_segments
        
        point_ids = []
        angle = start
        for i in range(num_segments + 1):
            x = cx + radius * math.cos(angle)
            y = cy + radius * math.sin(angle)
            pid = points.InsertNextPoint(x, y, cz)
            point_ids.append(pid)
            angle += step
        
        polyline = vtk.vtkPolyLine()
        polyline.GetPointIds().SetNumberOfIds(len(point_ids))
        for i, pid in enumerate(point_ids):
            polyline.GetPointIds().SetId(i, pid)
        lines.InsertNextCell(polyline)
        
        arc = vtk.vtkPolyData()
        arc.SetPoints(points)
        arc.SetLines(lines)
        
        # Arrow head
        if len(point_ids) >= 2:
            p1 = points.GetPoint(point_ids[-2])
            p2 = points.GetPoint(point_ids[-1])
            dx = p2[0] - p1[0]
            dy = p2[1] - p1[1]
            length = math.sqrt(dx*dx + dy*dy)
            if length > 0.001:
                dx /= length
                dy /= length
                
                head_len = 0.06
                head_wid = 0.03
                
                head_pts = vtk.vtkPoints()
                head_pts.InsertNextPoint(p2[0], p2[1], cz)
                head_pts.InsertNextPoint(
                    p2[0] - dx*head_len + dy*head_wid,
                    p2[1] - dy*head_len - dx*head_wid,
                    cz
                )
                head_pts.InsertNextPoint(
                    p2[0] - dx*head_len - dy*head_wid,
                    p2[1] - dy*head_len + dx*head_wid,
                    cz
                )
                
                head_cells = vtk.vtkCellArray()
                head_cells.InsertNextCell(3)
                head_cells.InsertCellPoint(0)
                head_cells.InsertCellPoint(1)
                head_cells.InsertCellPoint(2)
                
                head_poly = vtk.vtkPolyData()
                head_poly.SetPoints(head_pts)
                head_poly.SetPolys(head_cells)
                
                append = vtk.vtkAppendPolyData()
                append.AddInputData(arc)
                append.AddInputData(head_poly)
                append.Update()
                combined = append.GetOutput()
            else:
                combined = arc
        else:
            combined = arc
        
        mapper = vtk.vtkPolyDataMapper()
        mapper.SetInputData(combined)
        
        actor = vtk.vtkActor()
        actor.SetMapper(mapper)
        actor.GetProperty().SetLineWidth(2.0)
        actor.GetProperty().SetOpacity(0.0)
        
        return actor
    
    def _create_static_arrow(self, joint_name):
        """Create a straight arrow for a joint"""
        child_link = self.urdf_parser.get_link_for_joint(joint_name)
        if not child_link:
            return
        
        arrow = vtk.vtkArrowSource()
        arrow.SetTipLength(0.08)
        arrow.SetTipRadius(0.025)
        arrow.SetShaftRadius(0.01)
        
        # Plus arrow (green)
        plus = vtk.vtkActor()
        plus.SetMapper(vtk.vtkPolyDataMapper())
        plus.GetMapper().SetInputConnection(arrow.GetOutputPort())
        plus.GetProperty().SetColor(0.0, 0.8, 0.0)
        plus.SetVisibility(False)
        
        # Minus arrow (red)
        minus = vtk.vtkActor()
        minus.SetMapper(vtk.vtkPolyDataMapper())
        minus.GetMapper().SetInputConnection(arrow.GetOutputPort())
        minus.GetProperty().SetColor(0.8, 0.0, 0.0)
        minus.SetVisibility(False)
        
        self.joint_arrows[joint_name] = {
            'plus': plus,
            'minus': minus,
            'link': child_link,
            'axis': self.urdf_parser.get_joint_axis(joint_name)
        }
        
        self.renderer.AddActor(plus)
        self.renderer.AddActor(minus)
    
    def show_joint_arrow(self, joint_name, direction):
        """Show arrow for a joint"""
        self.hide_all_arrows()
        
        if joint_name not in self.joint_arrows:
            return
        
        arrow_info = self.joint_arrows[joint_name]
        
        if joint_name == 'joint1':
            actor = arrow_info.get(direction)
            if actor:
                actor.SetVisibility(True)
                actor.GetProperty().SetOpacity(1.0)
                self.vtk_widget.GetRenderWindow().Render()
            return
        
        # For joints 2-4, snap to mesh position
        actor = arrow_info.get(direction)
        child_link = arrow_info.get('link')
        
        if not actor or not child_link or child_link not in self.link_actors:
            return
        
        mesh_actor = self.link_actors[child_link]
        current_transform = mesh_actor.GetUserTransform()
        if not current_transform:
            return
        
        # Create transform for arrow
        arrow_transform = vtk.vtkTransform()
        arrow_transform.DeepCopy(current_transform)
        
        # Scale down
        arrow_transform.Scale(0.15, 0.15, 0.15)
        
        actor.SetUserTransform(arrow_transform)
        actor.SetVisibility(True)
        actor.GetProperty().SetOpacity(1.0)
        
        self.vtk_widget.GetRenderWindow().Render()
    
    def hide_all_arrows(self):
        """Hide all joint arrows"""
        for joint_name, arrow_info in self.joint_arrows.items():
            if joint_name == 'joint1':
                for d in ['plus', 'minus']:
                    actor = arrow_info.get(d)
                    if actor:
                        actor.SetVisibility(False)
            else:
                for d in ['plus', 'minus']:
                    actor = arrow_info.get(d)
                    if actor:
                        actor.SetVisibility(False)
        
        if self.vtk_widget:
            self.vtk_widget.GetRenderWindow().Render()
    
    def setup_tf(self, node):
        """Setup TF listener"""
        if ROS2_AVAILABLE and node is not None:
            try:
                self.tf_buffer = tf2_ros.Buffer()
                self.tf_listener = tf2_ros.TransformListener(self.tf_buffer, node)
                self.tf_initialized = True
                print("✓ TF2 buffer and listener created")
                print(f"  Waiting for transforms... (links: {list(self.link_actors.keys())})")
                return True
            except Exception as e:
                print(f"⚠ TF2 initialization failed: {e}")
                return False
        return False
    
    def update_from_tf(self):
        """Update robot poses from TF"""
        if not self.tf_initialized or self.tf_buffer is None:
            return
        
        try:
            any_update = False
            
            for link_name in self.link_actors.keys():
                try:
                    # Try to get transform from base_link to this link
                    transform = self.tf_buffer.lookup_transform(
                        'base_link', link_name, rclpy.time.Time(), timeout=rclpy.duration.Duration(seconds=0.01)
                    )
                    
                    if transform:
                        vtk_transform = self._convert_tf_to_vtk(transform)
                        
                        # Apply visual offset from URDF
                        xyz, rpy = self.urdf_parser.get_visual_origin(link_name)
                        if xyz != [0,0,0] or rpy != [0,0,0]:
                            offset = vtk.vtkTransform()
                            offset.Translate(xyz[0], xyz[1], xyz[2])
                            offset.RotateX(math.degrees(rpy[0]))
                            offset.RotateY(math.degrees(rpy[1]))
                            offset.RotateZ(math.degrees(rpy[2]))
                            
                            combined = vtk.vtkTransform()
                            combined.Concatenate(vtk_transform)
                            combined.Concatenate(offset)
                            vtk_transform = combined
                        
                        actor = self.link_actors[link_name]
                        actor.SetUserTransform(vtk_transform)
                        self.link_transforms[link_name] = vtk_transform
                        any_update = True
                        
                except (tf2_ros.LookupException, tf2_ros.ExtrapolationException):
                    # Transform not available yet - this is normal
                    pass
                except Exception as e:
                    pass
            
            # Render if we had any update
            if any_update and self.vtk_widget:
                self.vtk_widget.GetRenderWindow().Render()
                
        except Exception as e:
            # Silently ignore errors
            pass
    
    def _convert_tf_to_vtk(self, transform_stamped):
        """Convert ROS TransformStamped to vtkTransform"""
        vtk_transform = vtk.vtkTransform()
        vtk_transform.Identity()
        
        # Translation
        trans = transform_stamped.transform.translation
        vtk_transform.Translate(trans.x, trans.y, trans.z)
        
        # Rotation (quaternion to matrix)
        q = transform_stamped.transform.rotation
        qx, qy, qz, qw = q.x, q.y, q.z, q.w
        
        # Normalize
        norm = math.sqrt(qx*qx + qy*qy + qz*qz + qw*qw)
        if norm > 1e-6:
            qx, qy, qz, qw = qx/norm, qy/norm, qz/norm, qw/norm
        
        # Build rotation matrix
        matrix = vtk.vtkMatrix4x4()
        matrix.Identity()
        
        xx, yy, zz = qx*qx, qy*qy, qz*qz
        xy, xz, yz = qx*qy, qx*qz, qy*qz
        wx, wy, wz = qw*qx, qw*qy, qw*qz
        
        matrix.SetElement(0, 0, 1 - 2*(yy + zz))
        matrix.SetElement(0, 1, 2*(xy - wz))
        matrix.SetElement(0, 2, 2*(xz + wy))
        
        matrix.SetElement(1, 0, 2*(xy + wz))
        matrix.SetElement(1, 1, 1 - 2*(xx + zz))
        matrix.SetElement(1, 2, 2*(yz - wx))
        
        matrix.SetElement(2, 0, 2*(xz - wy))
        matrix.SetElement(2, 1, 2*(yz + wx))
        matrix.SetElement(2, 2, 1 - 2*(xx + yy))
        
        vtk_transform.Concatenate(matrix)
        return vtk_transform
    
    def get_transform_to_link(self, link_name, joint_positions):
        # Traverse up to find the path from base_link to link_name
        path = []
        curr = link_name
        while curr in self.urdf_parser.kinematic_chain and curr != 'base_link':
            parent = self.urdf_parser.kinematic_chain[curr]
            joint_name = self.urdf_parser.link_to_joint.get(curr)
            path.append((parent, joint_name, curr))
            curr = parent
        
        path.reverse()
        
        t = vtk.vtkTransform()
        t.Identity()
        
        for parent, joint_name, child in path:
            joint_data = self.urdf_parser.joint_transforms.get(joint_name)
            if not joint_data:
                continue
                
            pos = joint_data['position']  # (x, y, z)
            rot = joint_data.get('rotation', (0.0, 0.0, 0.0))  # (roll, pitch, yaw)
            
            # Parent-to-joint translation & rotation (Roll, Pitch, Yaw)
            t.Translate(pos[0], pos[1], pos[2])
            t.RotateX(math.degrees(rot[0]))
            t.RotateY(math.degrees(rot[1]))
            t.RotateZ(math.degrees(rot[2]))
            
            # Joint motion (rotation around joint axis)
            joint_type = joint_data.get('type', 'revolute')
            if joint_type in ['revolute', 'continuous']:
                angle = joint_positions.get(joint_name, 0.0)
                axis = self.urdf_parser.joint_axes.get(joint_name, [0.0, 0.0, 1.0])
                t.RotateWXYZ(math.degrees(angle), axis[0], axis[1], axis[2])
                
        return t

    def show_ghost_trajectory(self, display_trajectory):
        """Display ghost robot for a planned trajectory"""
        self.clear_ghost()
        
        if not display_trajectory or not display_trajectory.model_states:
            print("⚠ No trajectory data for ghost")
            return
        
        print(f"✓ Showing ghost with {len(display_trajectory.model_states)} waypoints")
        
        # Store waypoints for animation
        self.ghost_waypoints = display_trajectory.model_states
        self.ghost_visible = True
        
        # 1. Update the ghost robot links to the final posture of the trajectory
        final_state = display_trajectory.model_states[-1]
        joint_positions = dict(zip(final_state.joint_state.name, final_state.joint_state.position))
        
        for link_name, actor in self.ghost_link_actors.items():
            vtk_transform = self.get_transform_to_link(link_name, joint_positions)
            
            # Apply visual offset from URDF
            xyz, rpy = self.urdf_parser.get_visual_origin(link_name)
            if xyz != [0,0,0] or rpy != [0,0,0]:
                offset = vtk.vtkTransform()
                offset.Translate(xyz[0], xyz[1], xyz[2])
                offset.RotateX(math.degrees(rpy[0]))
                offset.RotateY(math.degrees(rpy[1]))
                offset.RotateZ(math.degrees(rpy[2]))
                
                combined = vtk.vtkTransform()
                combined.Concatenate(vtk_transform)
                combined.Concatenate(offset)
                vtk_transform = combined
                
            actor.SetUserTransform(vtk_transform)
            actor.SetVisibility(True)
            
        # 2. Draw the end-effector trajectory path as small spheres
        ee_link = 'link6'
        if 'link6' not in self.ghost_link_actors:
            # Fallback to case-insensitive match
            for k in self.ghost_link_actors.keys():
                if k.lower() == 'link6':
                    ee_link = k
                    break
        
        for i, state in enumerate(display_trajectory.model_states):
            state_joints = dict(zip(state.joint_state.name, state.joint_state.position))
            ee_tf = self.get_transform_to_link(ee_link, state_joints)
            pos = ee_tf.GetPosition()
            
            # Create a small sphere at the end-effector position
            sphere = vtk.vtkSphereSource()
            sphere.SetRadius(0.01)
            mapper = vtk.vtkPolyDataMapper()
            mapper.SetInputConnection(sphere.GetOutputPort())
            
            actor = vtk.vtkActor()
            actor.SetMapper(mapper)
            
            # Color based on position in trajectory (gradient: cyan/green to blue)
            t = i / max(1, len(display_trajectory.model_states) - 1)
            color = (0.0, 1.0 - 0.5 * t, 0.5 + 0.5 * t)  # Cyan to Blue gradient
            actor.GetProperty().SetColor(color)
            actor.GetProperty().SetOpacity(0.8)
            actor.SetPosition(pos)
            
            self.renderer.AddActor(actor)
            self.ghost_actors.append(actor)
            
        self.vtk_widget.GetRenderWindow().Render()
    
    def clear_ghost(self):
        """Remove ghost robot"""
        for actor in self.ghost_link_actors.values():
            actor.SetVisibility(False)
            
        for actor in self.ghost_actors:
            self.renderer.RemoveActor(actor)
        self.ghost_actors.clear()
        self.ghost_waypoints.clear()
        self.ghost_visible = False
        
        if self.vtk_widget:
            self.vtk_widget.GetRenderWindow().Render()